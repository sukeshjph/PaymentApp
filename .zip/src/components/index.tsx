/* eslint-disable */
import React, { PureComponent } from 'react';

class HelloWorld extends PureComponent {
    render() {
        return (
            <div id="stress-ui-content">
                 Hello world!!
            </div>
        );
    }
}

export default HelloWorld;
