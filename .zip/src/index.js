import React from 'react';
import ReactDom from 'react-dom';
// import configureStore from './store';
import App from './components';

// const store = configureStore();

ReactDom.render(<App />, document.getElementById('stress-ui-frame'));
