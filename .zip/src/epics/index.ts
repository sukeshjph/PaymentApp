// import { combineEpics } from 'redux-observable';
// import batchSummaryEpics from '../components/batchSummary/batchSummaryEpics';
// import batchDetailsEpics from '../components/batchDetails/batchDetailsEpics';
// import scenarioEpics from '../components/scenarioManager/scenarioEpics';
// import batchAuditEpics from '../components/batchAudit/batchAuditEpics';
// import scenarioAuditEpics from '../components/scenarioAudit/scenarioAuditEpics';
// import inboxEpics from '../components/inbox/inboxEpics';
// import downloadsEpics from '../components/downloads/downloadsEpics';
// import batchScheduleEpics from '../components/batchSchedule/batchScheduleEpics';
// import rootEpics from './rootEpics';

// export default combineEpics(
//     batchSummaryEpics,
//     batchDetailsEpics,
//     batchScheduleEpics,
//     batchAuditEpics,
//     scenarioAuditEpics,
//     scenarioEpics,
//     inboxEpics,
//     downloadsEpics,
//     rootEpics,
// );
