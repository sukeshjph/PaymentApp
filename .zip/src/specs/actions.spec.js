import * as actions from '../actions';
import { diffActionTypes } from '../constants';

jest.mock('../helpers/authentication');

describe('"fetchDiff" action', () => {
    it('dispatches a FETCH_DIFF action', () => {
        const ukId = '123456789';
        const file = {};
        const fileVersionToCompare = 1;
        expect(actions.fetchDiff(ukId, file, fileVersionToCompare).type)
            .toEqual(diffActionTypes.FETCH_DIFF);
        expect(actions.fetchDiff(ukId, file, fileVersionToCompare).payload)
            .toEqual({ ukId, file, fileVersionToCompare });
    });
});