export default {
    rows: [
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/fdsf/shockType=FX/shockName=FDSF/reportName=aggregate/cobDate=2018-06-29/version=1',
            newDataSetId:
                'appsets/marketrisk/stress/fdsf/shockType=FX/shockName=FDSF/reportName=aggregate/cobDate=2018-06-29/version=1',
            className: 'reports__row',
            fds: 'fdsf',
            shockType: 'FX',
            shockName: 'FDSF',
            reportName: 'aggregate',
            cobDate: '2018-06-29',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/fdsf/shockType=FX/shockName=FDSF/reportName=error/cobDate=2018-06-29/version=1',
            newDataSetId:
                'appsets/marketrisk/stress/fdsf/shockType=FX/shockName=FDSF/reportName=error/cobDate=2018-06-29/version=1',
            className: 'reports__row',
            fds: 'fdsf',
            shockType: 'FX',
            shockName: 'FDSF',
            reportName: 'error',
            cobDate: '2018-06-29',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/fdsf/shockType=FX/shockName=FDSF/reportName=trades/cobDate=2018-06-29/version=1',
            newDataSetId:
                'appsets/marketrisk/stress/fdsf/shockType=FX/shockName=FDSF/reportName=trades/cobDate=2018-06-29/version=1',
            className: 'reports__row',
            fds: 'fdsf',
            shockType: 'FX',
            shockName: 'FDSF',
            reportName: 'trades',
            cobDate: '2018-06-29',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/fdsf/shockType=IR/shockName=FDSF/reportName=aggregate/cobDate=2018-06-29/version=1',
            newDataSetId:
                'appsets/marketrisk/stress/fdsf/shockType=IR/shockName=FDSF/reportName=aggregate/cobDate=2018-06-29/version=1',
            className: 'reports__row',
            fds: 'fdsf',
            shockType: 'IR',
            shockName: 'FDSF',
            reportName: 'aggregate',
            cobDate: '2018-06-29',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/fdsf/shockType=IR/shockName=FDSF/reportName=error/cobDate=2018-06-29/version=1',
            newDataSetId:
                'appsets/marketrisk/stress/fdsf/shockType=IR/shockName=FDSF/reportName=error/cobDate=2018-06-29/version=1',
            className: 'reports__row',
            fds: 'fdsf',
            shockType: 'IR',
            shockName: 'FDSF',
            reportName: 'error',
            cobDate: '2018-06-29',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/fdsf/shockType=IR/shockName=FDSF/reportName=trades/cobDate=2018-06-29/version=1',
            newDataSetId:
                'appsets/marketrisk/stress/fdsf/shockType=IR/shockName=FDSF/reportName=trades/cobDate=2018-06-29/version=1',
            className: 'reports__row',
            fds: 'fdsf',
            shockType: 'IR',
            shockName: 'FDSF',
            reportName: 'trades',
            cobDate: '2018-06-29',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/shockType=global/Acrimonious_Brexit_Triggers_Global_Risk_Aversion/cobDate=2018-03-23/version=1',
            newDataSetId:
                'appsets/marketrisk/stress/shockType=global/Acrimonious_Brexit_Triggers_Global_Risk_Aversion/cobDate=2018-03-23/version=1',
            className: 'reports__row',
            shockType: 'global',
            Acrimonious_Brexit_Triggers_Global_Risk_Aversio:
                'Acrimonious_Brexit_Triggers_Global_Risk_Aversion',
            cobDate: '2018-03-23',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/shockType=global/Bond_Armageddon/cobDate=2018-03-23/version=1',
            newDataSetId:
                'appsets/marketrisk/stress/shockType=global/Bond_Armageddon/cobDate=2018-03-23/version=1',
            className: 'reports__row',
            shockType: 'global',
            Bond_Armageddo: 'Bond_Armageddon',
            cobDate: '2018-03-23',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/shockType=global/Middle_East_War/cobDate=2018-03-23/version=1',
            newDataSetId:
                'appsets/marketrisk/stress/shockType=global/Middle_East_War/cobDate=2018-03-23/version=1',
            className: 'reports__row',
            shockType: 'global',
            Middle_East_Wa: 'Middle_East_War',
            cobDate: '2018-03-23',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/shockType=global/Oil_Price_Slump/cobDate=2018-03-23/version=1',
            newDataSetId:
                'appsets/marketrisk/stress/shockType=global/Oil_Price_Slump/cobDate=2018-03-23/version=1',
            className: 'reports__row',
            shockType: 'global',
            Oil_Price_Slum: 'Oil_Price_Slump',
            cobDate: '2018-03-23',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/shockType=global/Oil_Price_Spike/cobDate=2018-03-23/version=1',
            newDataSetId:
                'appsets/marketrisk/stress/shockType=global/Oil_Price_Spike/cobDate=2018-03-23/version=1',
            className: 'reports__row',
            shockType: 'global',
            Oil_Price_Spik: 'Oil_Price_Spike',
            cobDate: '2018-03-23',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/shockType=global/shockName=Acrimonious_Brexit_Triggers_Global_Risk_Aversion/reportName=trades/cobDate=2018-03-23/version=1',
            newDataSetId:
                'appsets/marketrisk/stress/shockType=global/shockName=Acrimonious_Brexit_Triggers_Global_Risk_Aversion/reportName=trades/cobDate=2018-03-23/version=1',
            className: 'reports__row',
            shockType: 'global',
            shockName: 'Acrimonious_Brexit_Triggers_Global_Risk_Aversion',
            reportName: 'trades',
            cobDate: '2018-03-23',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/shockType=global/shockName=Bond_Armageddon/reportName=trades/cobDate=2018-03-23/version=1',
            newDataSetId:
                'appsets/marketrisk/stress/shockType=global/shockName=Bond_Armageddon/reportName=trades/cobDate=2018-03-23/version=1',
            className: 'reports__row',
            shockType: 'global',
            shockName: 'Bond_Armageddon',
            reportName: 'trades',
            cobDate: '2018-03-23',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/shockType=global/shockName=Middle_East_War/reportName=trades/cobDate=2018-03-23/version=1',
            newDataSetId:
                'appsets/marketrisk/stress/shockType=global/shockName=Middle_East_War/reportName=trades/cobDate=2018-03-23/version=1',
            className: 'reports__row',
            shockType: 'global',
            shockName: 'Middle_East_War',
            reportName: 'trades',
            cobDate: '2018-03-23',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/shockType=global/shockName=Oil_Price_Slump/reportName=trades/cobDate=2018-03-23/version=1',
            newDataSetId:
                'appsets/marketrisk/stress/shockType=global/shockName=Oil_Price_Slump/reportName=trades/cobDate=2018-03-23/version=1',
            className: 'reports__row',
            shockType: 'global',
            shockName: 'Oil_Price_Slump',
            reportName: 'trades',
            cobDate: '2018-03-23',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/shockType=global/shockName=Oil_Price_Spike/reportName=trades/cobDate=2018-03-23/version=1',
            newDataSetId:
                'appsets/marketrisk/stress/shockType=global/shockName=Oil_Price_Spike/reportName=trades/cobDate=2018-03-23/version=1',
            className: 'reports__row',
            shockType: 'global',
            shockName: 'Oil_Price_Spike',
            reportName: 'trades',
            cobDate: '2018-03-23',
            version: '1',
        },
        {
            files: null,
            oldDataSetId: 'appsets/marketrisk/stress/errors/global/date=2018-02-26/version=1',
            newDataSetId:
                'shockType=global/shockName=All/reportName=error/cobDate=2018-02-26/version=1',
            className: '',
            shockType: 'global',
            shockName: 'All',
            reportName: 'error',
            cobDate: '2018-02-26',
            version: '1',
        },
        {
            files: null,
            oldDataSetId: 'appsets/marketrisk/stress/errors/global/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=global/shockName=All/reportName=error/cobDate=2018-03-16/version=1',
            className: '',
            shockType: 'global',
            shockName: 'All',
            reportName: 'error',
            cobDate: '2018-03-16',
            version: '1',
        },
        {
            files: null,
            oldDataSetId: 'appsets/marketrisk/stress/errors/global/date=2018-03-23/version=1',
            newDataSetId:
                'shockType=global/shockName=All/reportName=error/cobDate=2018-03-23/version=1',
            className: '',
            shockType: 'global',
            shockName: 'All',
            reportName: 'error',
            cobDate: '2018-03-23',
            version: '1',
        },
        {
            files: null,
            oldDataSetId: 'appsets/marketrisk/stress/errors/localised/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=localised/shockName=All/reportName=error/cobDate=2018-03-16/version=1',
            className: '',
            shockType: 'localised',
            shockName: 'All',
            reportName: 'error',
            cobDate: '2018-03-16',
            version: '1',
        },
        {
            files: null,
            oldDataSetId: 'appsets/marketrisk/stress/errors/localised/date=2018-03-23/version=1',
            newDataSetId:
                'shockType=localised/shockName=All/reportName=error/cobDate=2018-03-23/version=1',
            className: '',
            shockType: 'localised',
            shockName: 'All',
            reportName: 'error',
            cobDate: '2018-03-23',
            version: '1',
        },
        {
            files: null,
            oldDataSetId: 'appsets/marketrisk/stress/fallback/global/date=2018-02-26/version=1',
            newDataSetId:
                'shockType=global/shockName=All/reportName=fallback/cobDate=2018-02-26/version=1',
            className: '',
            shockType: 'global',
            shockName: 'All',
            reportName: 'fallback',
            cobDate: '2018-02-26',
            version: '1',
        },
        {
            files: null,
            oldDataSetId: 'appsets/marketrisk/stress/fallback/global/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=global/shockName=All/reportName=fallback/cobDate=2018-03-16/version=1',
            className: '',
            shockType: 'global',
            shockName: 'All',
            reportName: 'fallback',
            cobDate: '2018-03-16',
            version: '1',
        },
        {
            files: null,
            oldDataSetId: 'appsets/marketrisk/stress/fallback/global/date=2018-03-23/version=1',
            newDataSetId:
                'shockType=global/shockName=All/reportName=fallback/cobDate=2018-03-23/version=1',
            className: '',
            shockType: 'global',
            shockName: 'All',
            reportName: 'fallback',
            cobDate: '2018-03-23',
            version: '1',
        },
        {
            files: null,
            oldDataSetId: 'appsets/marketrisk/stress/fallback/localised/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=localised/shockName=All/reportName=fallback/cobDate=2018-03-16/version=1',
            className: '',
            shockType: 'localised',
            shockName: 'All',
            reportName: 'fallback',
            cobDate: '2018-03-16',
            version: '1',
        },
        {
            files: null,
            oldDataSetId: 'appsets/marketrisk/stress/fallback/localised/date=2018-03-23/version=1',
            newDataSetId:
                'shockType=localised/shockName=All/reportName=fallback/cobDate=2018-03-23/version=1',
            className: '',
            shockType: 'localised',
            shockName: 'All',
            reportName: 'fallback',
            cobDate: '2018-03-23',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/global/Acrimonious_Brexit_Triggers_Global_Risk_Aversion/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=global/reportName=trades/Acrimonious_Brexit_Triggers_Global_Risk_Aversion/cobDate=2018-03-16/version=1/shockName=Acrimonious_Brexit_Triggers_Global_Risk_Aversion',
            className: '',
            shockType: 'global',
            reportName: 'trades',
            Acrimonious_Brexit_Triggers_Global_Risk_Aversio:
                'Acrimonious_Brexit_Triggers_Global_Risk_Aversion',
            cobDate: '2018-03-16',
            version: '1',
            shockName: 'Acrimonious_Brexit_Triggers_Global_Risk_Aversion',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/global/Acrimonious_Brexit_Triggers_Global_Risk_Aversion/date=2018-03-23/version=1',
            newDataSetId:
                'shockType=global/reportName=trades/Acrimonious_Brexit_Triggers_Global_Risk_Aversion/cobDate=2018-03-23/version=1/shockName=Acrimonious_Brexit_Triggers_Global_Risk_Aversion',
            className: '',
            shockType: 'global',
            reportName: 'trades',
            Acrimonious_Brexit_Triggers_Global_Risk_Aversio:
                'Acrimonious_Brexit_Triggers_Global_Risk_Aversion',
            cobDate: '2018-03-23',
            version: '1',
            shockName: 'Acrimonious_Brexit_Triggers_Global_Risk_Aversion',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/global/Acrimonious_Brexit_Triggers_Global_Risk_Aversion-20180223022915/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=global/reportName=trades/Acrimonious_Brexit_Triggers_Global_Risk_Aversion-20180223022915/cobDate=2018-03-16/version=1/shockName=Acrimonious_Brexit_Triggers_Global_Risk_Aversion-20180223022915',
            className: '',
            shockType: 'global',
            reportName: 'trades',
            'Acrimonious_Brexit_Triggers_Global_Risk_Aversion-2018022302291':
                'Acrimonious_Brexit_Triggers_Global_Risk_Aversion-20180223022915',
            cobDate: '2018-03-16',
            version: '1',
            shockName: 'Acrimonious_Brexit_Triggers_Global_Risk_Aversion-20180223022915',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/global/Bond_Armageddon/date=2018-03-23/version=1',
            newDataSetId:
                'shockType=global/reportName=trades/Bond_Armageddon/cobDate=2018-03-23/version=1/shockName=Bond_Armageddon',
            className: '',
            shockType: 'global',
            reportName: 'trades',
            Bond_Armageddo: 'Bond_Armageddon',
            cobDate: '2018-03-23',
            version: '1',
            shockName: 'Bond_Armageddon',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/global/BrexitGlobalShock/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=global/reportName=trades/BrexitGlobalShock/cobDate=2018-03-16/version=1/shockName=BrexitGlobalShock',
            className: '',
            shockType: 'global',
            reportName: 'trades',
            BrexitGlobalShoc: 'BrexitGlobalShock',
            cobDate: '2018-03-16',
            version: '1',
            shockName: 'BrexitGlobalShock',
        },
        {
            files: null,
            oldDataSetId: 'appsets/marketrisk/stress/global/CNY/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=global/reportName=trades/CNY/cobDate=2018-03-16/version=1/shockName=CNY',
            className: '',
            shockType: 'global',
            reportName: 'trades',
            CN: 'CNY',
            cobDate: '2018-03-16',
            version: '1',
            shockName: 'CNY',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/global/CNY-20180223022948/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=global/reportName=trades/CNY-20180223022948/cobDate=2018-03-16/version=1/shockName=CNY-20180223022948',
            className: '',
            shockType: 'global',
            reportName: 'trades',
            'CNY-2018022302294': 'CNY-20180223022948',
            cobDate: '2018-03-16',
            version: '1',
            shockName: 'CNY-20180223022948',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/global/Middle_East_Scn/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=global/reportName=trades/Middle_East_Scn/cobDate=2018-03-16/version=1/shockName=Middle_East_Scn',
            className: '',
            shockType: 'global',
            reportName: 'trades',
            Middle_East_Sc: 'Middle_East_Scn',
            cobDate: '2018-03-16',
            version: '1',
            shockName: 'Middle_East_Scn',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/global/Middle_East_War/date=2018-03-23/version=1',
            newDataSetId:
                'shockType=global/reportName=trades/Middle_East_War/cobDate=2018-03-23/version=1/shockName=Middle_East_War',
            className: '',
            shockType: 'global',
            reportName: 'trades',
            Middle_East_Wa: 'Middle_East_War',
            cobDate: '2018-03-23',
            version: '1',
            shockName: 'Middle_East_War',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/global/Oil_Price_Slump/date=2018-03-23/version=1',
            newDataSetId:
                'shockType=global/reportName=trades/Oil_Price_Slump/cobDate=2018-03-23/version=1/shockName=Oil_Price_Slump',
            className: '',
            shockType: 'global',
            reportName: 'trades',
            Oil_Price_Slum: 'Oil_Price_Slump',
            cobDate: '2018-03-23',
            version: '1',
            shockName: 'Oil_Price_Slump',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/global/Oil_Price_Spike/date=2018-03-23/version=1',
            newDataSetId:
                'shockType=global/reportName=trades/Oil_Price_Spike/cobDate=2018-03-23/version=1/shockName=Oil_Price_Spike',
            className: '',
            shockType: 'global',
            reportName: 'trades',
            Oil_Price_Spik: 'Oil_Price_Spike',
            cobDate: '2018-03-23',
            version: '1',
            shockName: 'Oil_Price_Spike',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/global/consolidated_desk/date=2017-10-19/version=1/blobs',
            newDataSetId:
                'shockType=global/shockName=All/reportName=consolidated_desk/cobDate=2017-10-19/version=1/blobs',
            className: '',
            shockType: 'global',
            shockName: 'All',
            reportName: 'consolidated_desk',
            cobDate: '2017-10-19',
            version: '1',
            blob: 'blobs',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/global/consolidated_desk/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=global/shockName=All/reportName=consolidated_desk/cobDate=2018-03-16/version=1',
            className: '',
            shockType: 'global',
            shockName: 'All',
            reportName: 'consolidated_desk',
            cobDate: '2018-03-16',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/global-missingshocks/Acrimonious_Brexit_Triggers_Global_Risk_Aversion/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=global/shockName=All/reportName=missing_shocks/Acrimonious_Brexit_Triggers_Global_Risk_Aversion/cobDate=2018-03-16/version=1',
            className: '',
            shockType: 'global',
            shockName: 'All',
            reportName: 'missing_shocks',
            Acrimonious_Brexit_Triggers_Global_Risk_Aversio:
                'Acrimonious_Brexit_Triggers_Global_Risk_Aversion',
            cobDate: '2018-03-16',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/global-missingshocks/Acrimonious_Brexit_Triggers_Global_Risk_Aversion/date=2018-03-23/version=1',
            newDataSetId:
                'shockType=global/shockName=All/reportName=missing_shocks/Acrimonious_Brexit_Triggers_Global_Risk_Aversion/cobDate=2018-03-23/version=1',
            className: '',
            shockType: 'global',
            shockName: 'All',
            reportName: 'missing_shocks',
            Acrimonious_Brexit_Triggers_Global_Risk_Aversio:
                'Acrimonious_Brexit_Triggers_Global_Risk_Aversion',
            cobDate: '2018-03-23',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/global-missingshocks/Acrimonious_Brexit_Triggers_Global_Risk_Aversion-20180223022915/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=global/shockName=All/reportName=missing_shocks/Acrimonious_Brexit_Triggers_Global_Risk_Aversion-20180223022915/cobDate=2018-03-16/version=1',
            className: '',
            shockType: 'global',
            shockName: 'All',
            reportName: 'missing_shocks',
            'Acrimonious_Brexit_Triggers_Global_Risk_Aversion-2018022302291':
                'Acrimonious_Brexit_Triggers_Global_Risk_Aversion-20180223022915',
            cobDate: '2018-03-16',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/global-missingshocks/Bond_Armageddon/date=2018-03-23/version=1',
            newDataSetId:
                'shockType=global/shockName=All/reportName=missing_shocks/Bond_Armageddon/cobDate=2018-03-23/version=1',
            className: '',
            shockType: 'global',
            shockName: 'All',
            reportName: 'missing_shocks',
            Bond_Armageddo: 'Bond_Armageddon',
            cobDate: '2018-03-23',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/global-missingshocks/BrexitGlobalShock/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=global/shockName=All/reportName=missing_shocks/BrexitGlobalShock/cobDate=2018-03-16/version=1',
            className: '',
            shockType: 'global',
            shockName: 'All',
            reportName: 'missing_shocks',
            BrexitGlobalShoc: 'BrexitGlobalShock',
            cobDate: '2018-03-16',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/global-missingshocks/CNY/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=global/shockName=All/reportName=missing_shocks/CNY/cobDate=2018-03-16/version=1',
            className: '',
            shockType: 'global',
            shockName: 'All',
            reportName: 'missing_shocks',
            CN: 'CNY',
            cobDate: '2018-03-16',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/global-missingshocks/CNY-20180223022948/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=global/shockName=All/reportName=missing_shocks/CNY-20180223022948/cobDate=2018-03-16/version=1',
            className: '',
            shockType: 'global',
            shockName: 'All',
            reportName: 'missing_shocks',
            'CNY-2018022302294': 'CNY-20180223022948',
            cobDate: '2018-03-16',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/global-missingshocks/Middle_East_Scn/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=global/shockName=All/reportName=missing_shocks/Middle_East_Scn/cobDate=2018-03-16/version=1',
            className: '',
            shockType: 'global',
            shockName: 'All',
            reportName: 'missing_shocks',
            Middle_East_Sc: 'Middle_East_Scn',
            cobDate: '2018-03-16',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/global-missingshocks/Middle_East_War/date=2018-03-23/version=1',
            newDataSetId:
                'shockType=global/shockName=All/reportName=missing_shocks/Middle_East_War/cobDate=2018-03-23/version=1',
            className: '',
            shockType: 'global',
            shockName: 'All',
            reportName: 'missing_shocks',
            Middle_East_Wa: 'Middle_East_War',
            cobDate: '2018-03-23',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/global-missingshocks/Oil_Price_Slump/date=2018-03-23/version=1',
            newDataSetId:
                'shockType=global/shockName=All/reportName=missing_shocks/Oil_Price_Slump/cobDate=2018-03-23/version=1',
            className: '',
            shockType: 'global',
            shockName: 'All',
            reportName: 'missing_shocks',
            Oil_Price_Slum: 'Oil_Price_Slump',
            cobDate: '2018-03-23',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/global-missingshocks/Oil_Price_Spike/date=2018-03-23/version=1',
            newDataSetId:
                'shockType=global/shockName=All/reportName=missing_shocks/Oil_Price_Spike/cobDate=2018-03-23/version=1',
            className: '',
            shockType: 'global',
            shockName: 'All',
            reportName: 'missing_shocks',
            Oil_Price_Spik: 'Oil_Price_Spike',
            cobDate: '2018-03-23',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/localised/LOCALISED_FX_SPOT/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=localised/reportName=trades/LOCALISED_FX_SPOT/cobDate=2018-03-16/version=1/shockName=LOCALISED_FX_SPOT',
            className: '',
            shockType: 'localised',
            reportName: 'trades',
            LOCALISED_FX_SPO: 'LOCALISED_FX_SPOT',
            cobDate: '2018-03-16',
            version: '1',
            shockName: 'LOCALISED_FX_SPOT',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/localised/LOCALISED_FX_SPOT/date=2018-03-23/version=1',
            newDataSetId:
                'shockType=localised/reportName=trades/LOCALISED_FX_SPOT/cobDate=2018-03-23/version=1/shockName=LOCALISED_FX_SPOT',
            className: '',
            shockType: 'localised',
            reportName: 'trades',
            LOCALISED_FX_SPO: 'LOCALISED_FX_SPOT',
            cobDate: '2018-03-23',
            version: '1',
            shockName: 'LOCALISED_FX_SPOT',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/localised/LOCALISED_FX_SPOT-20180302151912/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=localised/reportName=trades/LOCALISED_FX_SPOT-20180302151912/cobDate=2018-03-16/version=1/shockName=LOCALISED_FX_SPOT-20180302151912',
            className: '',
            shockType: 'localised',
            reportName: 'trades',
            'LOCALISED_FX_SPOT-2018030215191': 'LOCALISED_FX_SPOT-20180302151912',
            cobDate: '2018-03-16',
            version: '1',
            shockName: 'LOCALISED_FX_SPOT-20180302151912',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/localised/LOCALISED_FX_SPOT_VOLS/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=localised/reportName=trades/LOCALISED_FX_SPOT_VOLS/cobDate=2018-03-16/version=1/shockName=LOCALISED_FX_SPOT_VOLS',
            className: '',
            shockType: 'localised',
            reportName: 'trades',
            LOCALISED_FX_SPOT_VOL: 'LOCALISED_FX_SPOT_VOLS',
            cobDate: '2018-03-16',
            version: '1',
            shockName: 'LOCALISED_FX_SPOT_VOLS',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/localised/LOCALISED_FX_SPOT_VOLS/date=2018-03-23/version=1',
            newDataSetId:
                'shockType=localised/reportName=trades/LOCALISED_FX_SPOT_VOLS/cobDate=2018-03-23/version=1/shockName=LOCALISED_FX_SPOT_VOLS',
            className: '',
            shockType: 'localised',
            reportName: 'trades',
            LOCALISED_FX_SPOT_VOL: 'LOCALISED_FX_SPOT_VOLS',
            cobDate: '2018-03-23',
            version: '1',
            shockName: 'LOCALISED_FX_SPOT_VOLS',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/localised/LOCALISED_FX_SPOT_VOLS-20180302152014/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=localised/reportName=trades/LOCALISED_FX_SPOT_VOLS-20180302152014/cobDate=2018-03-16/version=1/shockName=LOCALISED_FX_SPOT_VOLS-20180302152014',
            className: '',
            shockType: 'localised',
            reportName: 'trades',
            'LOCALISED_FX_SPOT_VOLS-2018030215201': 'LOCALISED_FX_SPOT_VOLS-20180302152014',
            cobDate: '2018-03-16',
            version: '1',
            shockName: 'LOCALISED_FX_SPOT_VOLS-20180302152014',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/localised/LOCALISED_FX_SPOT_VOLS_RR/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=localised/reportName=trades/LOCALISED_FX_SPOT_VOLS_RR/cobDate=2018-03-16/version=1/shockName=LOCALISED_FX_SPOT_VOLS_RR',
            className: '',
            shockType: 'localised',
            reportName: 'trades',
            LOCALISED_FX_SPOT_VOLS_R: 'LOCALISED_FX_SPOT_VOLS_RR',
            cobDate: '2018-03-16',
            version: '1',
            shockName: 'LOCALISED_FX_SPOT_VOLS_RR',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/localised/LOCALISED_FX_SPOT_VOLS_RR-20180305121521/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=localised/reportName=trades/LOCALISED_FX_SPOT_VOLS_RR-20180305121521/cobDate=2018-03-16/version=1/shockName=LOCALISED_FX_SPOT_VOLS_RR-20180305121521',
            className: '',
            shockType: 'localised',
            reportName: 'trades',
            'LOCALISED_FX_SPOT_VOLS_RR-2018030512152': 'LOCALISED_FX_SPOT_VOLS_RR-20180305121521',
            cobDate: '2018-03-16',
            version: '1',
            shockName: 'LOCALISED_FX_SPOT_VOLS_RR-20180305121521',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/localised/LocalisedIRCurveAndVolShocks/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=localised/reportName=trades/LocalisedIRCurveAndVolShocks/cobDate=2018-03-16/version=1/shockName=LocalisedIRCurveAndVolShocks',
            className: '',
            shockType: 'localised',
            reportName: 'trades',
            LocalisedIRCurveAndVolShock: 'LocalisedIRCurveAndVolShocks',
            cobDate: '2018-03-16',
            version: '1',
            shockName: 'LocalisedIRCurveAndVolShocks',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/localised/LocalisedIRCurveAndVolShocks_Region/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=localised/reportName=trades/LocalisedIRCurveAndVolShocks_Region/cobDate=2018-03-16/version=1/shockName=LocalisedIRCurveAndVolShocks_Region',
            className: '',
            shockType: 'localised',
            reportName: 'trades',
            LocalisedIRCurveAndVolShocks_Regio: 'LocalisedIRCurveAndVolShocks_Region',
            cobDate: '2018-03-16',
            version: '1',
            shockName: 'LocalisedIRCurveAndVolShocks_Region',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/localised/Localised_Stress_Commodities/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=localised/reportName=trades/Localised_Stress_Commodities/cobDate=2018-03-16/version=1/shockName=Localised_Stress_Commodities',
            className: '',
            shockType: 'localised',
            reportName: 'trades',
            Localised_Stress_Commoditie: 'Localised_Stress_Commodities',
            cobDate: '2018-03-16',
            version: '1',
            shockName: 'Localised_Stress_Commodities',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/localised/SPT_Rates_Supplementary/date=2018-03-23/version=1',
            newDataSetId:
                'shockType=localised/reportName=trades/SPT_Rates_Supplementary/cobDate=2018-03-23/version=1/shockName=SPT_Rates_Supplementary',
            className: '',
            shockType: 'localised',
            reportName: 'trades',
            SPT_Rates_Supplementar: 'SPT_Rates_Supplementary',
            cobDate: '2018-03-23',
            version: '1',
            shockName: 'SPT_Rates_Supplementary',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/localised/TestLMMshift/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=localised/reportName=trades/TestLMMshift/cobDate=2018-03-16/version=1/shockName=TestLMMshift',
            className: '',
            shockType: 'localised',
            reportName: 'trades',
            TestLMMshif: 'TestLMMshift',
            cobDate: '2018-03-16',
            version: '1',
            shockName: 'TestLMMshift',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/localised-missingshocks/LOCALISED_FX_SPOT/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=localised/shockName=All/reportName=missing_shocks/LOCALISED_FX_SPOT/cobDate=2018-03-16/version=1',
            className: '',
            shockType: 'localised',
            shockName: 'All',
            reportName: 'missing_shocks',
            LOCALISED_FX_SPO: 'LOCALISED_FX_SPOT',
            cobDate: '2018-03-16',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/localised-missingshocks/LOCALISED_FX_SPOT/date=2018-03-23/version=1',
            newDataSetId:
                'shockType=localised/shockName=All/reportName=missing_shocks/LOCALISED_FX_SPOT/cobDate=2018-03-23/version=1',
            className: '',
            shockType: 'localised',
            shockName: 'All',
            reportName: 'missing_shocks',
            LOCALISED_FX_SPO: 'LOCALISED_FX_SPOT',
            cobDate: '2018-03-23',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/localised-missingshocks/LOCALISED_FX_SPOT_VOLS/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=localised/shockName=All/reportName=missing_shocks/LOCALISED_FX_SPOT_VOLS/cobDate=2018-03-16/version=1',
            className: '',
            shockType: 'localised',
            shockName: 'All',
            reportName: 'missing_shocks',
            LOCALISED_FX_SPOT_VOL: 'LOCALISED_FX_SPOT_VOLS',
            cobDate: '2018-03-16',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/localised-missingshocks/LOCALISED_FX_SPOT_VOLS/date=2018-03-23/version=1',
            newDataSetId:
                'shockType=localised/shockName=All/reportName=missing_shocks/LOCALISED_FX_SPOT_VOLS/cobDate=2018-03-23/version=1',
            className: '',
            shockType: 'localised',
            shockName: 'All',
            reportName: 'missing_shocks',
            LOCALISED_FX_SPOT_VOL: 'LOCALISED_FX_SPOT_VOLS',
            cobDate: '2018-03-23',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/localised-missingshocks/LOCALISED_FX_SPOT_VOLS_RR/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=localised/shockName=All/reportName=missing_shocks/LOCALISED_FX_SPOT_VOLS_RR/cobDate=2018-03-16/version=1',
            className: '',
            shockType: 'localised',
            shockName: 'All',
            reportName: 'missing_shocks',
            LOCALISED_FX_SPOT_VOLS_R: 'LOCALISED_FX_SPOT_VOLS_RR',
            cobDate: '2018-03-16',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/localised-missingshocks/LocalisedIRCurveAndVolShocks/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=localised/shockName=All/reportName=missing_shocks/LocalisedIRCurveAndVolShocks/cobDate=2018-03-16/version=1',
            className: '',
            shockType: 'localised',
            shockName: 'All',
            reportName: 'missing_shocks',
            LocalisedIRCurveAndVolShock: 'LocalisedIRCurveAndVolShocks',
            cobDate: '2018-03-16',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/localised-missingshocks/LocalisedIRCurveAndVolShocks_Region/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=localised/shockName=All/reportName=missing_shocks/LocalisedIRCurveAndVolShocks_Region/cobDate=2018-03-16/version=1',
            className: '',
            shockType: 'localised',
            shockName: 'All',
            reportName: 'missing_shocks',
            LocalisedIRCurveAndVolShocks_Regio: 'LocalisedIRCurveAndVolShocks_Region',
            cobDate: '2018-03-16',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/localised-missingshocks/Localised_Stress_Commodities/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=localised/shockName=All/reportName=missing_shocks/Localised_Stress_Commodities/cobDate=2018-03-16/version=1',
            className: '',
            shockType: 'localised',
            shockName: 'All',
            reportName: 'missing_shocks',
            Localised_Stress_Commoditie: 'Localised_Stress_Commodities',
            cobDate: '2018-03-16',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/localised-missingshocks/SPT_Rates_Supplementary/date=2018-03-23/version=1',
            newDataSetId:
                'shockType=localised/shockName=All/reportName=missing_shocks/SPT_Rates_Supplementary/cobDate=2018-03-23/version=1',
            className: '',
            shockType: 'localised',
            shockName: 'All',
            reportName: 'missing_shocks',
            SPT_Rates_Supplementar: 'SPT_Rates_Supplementary',
            cobDate: '2018-03-23',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/stress/localised-missingshocks/TestLMMshift/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=localised/shockName=All/reportName=missing_shocks/TestLMMshift/cobDate=2018-03-16/version=1',
            className: '',
            shockType: 'localised',
            shockName: 'All',
            reportName: 'missing_shocks',
            TestLMMshif: 'TestLMMshift',
            cobDate: '2018-03-16',
            version: '1',
        },
        {
            files: null,
            oldDataSetId: 'appsets/marketrisk/stress/summary/batch/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=*/shockName=All/reportName=batch_summary/cobDate=2018-03-16/version=1',
            className: '',
            shockType: '*',
            shockName: 'All',
            reportName: 'batch_summary',
            cobDate: '2018-03-16',
            version: '1',
        },
        {
            files: null,
            oldDataSetId: 'appsets/marketrisk/stress/summary/batch/date=2018-03-23/version=1',
            newDataSetId:
                'shockType=*/shockName=All/reportName=batch_summary/cobDate=2018-03-23/version=1',
            className: '',
            shockType: '*',
            shockName: 'All',
            reportName: 'batch_summary',
            cobDate: '2018-03-23',
            version: '1',
        },
        {
            files: null,
            oldDataSetId: 'appsets/marketrisk/stress/summary/performance/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=*/shockName=All/reportName=performance_summary/cobDate=2018-03-16/version=1',
            className: '',
            shockType: '*',
            shockName: 'All',
            reportName: 'performance_summary',
            cobDate: '2018-03-16',
            version: '1',
        },
        {
            files: null,
            oldDataSetId: 'appsets/marketrisk/stress/summary/sensitivity/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=*/shockName=All/reportName=sensitivities_summary/cobDate=2018-03-16/version=1',
            className: '',
            shockType: '*',
            shockName: 'All',
            reportName: 'sensitivities_summary',
            cobDate: '2018-03-16',
            version: '1',
        },
        {
            files: null,
            oldDataSetId: 'appsets/marketrisk/active_pivot/global_stress/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=global/shockName=All/reportName=active_pivot/cobDate=2018-03-16/version=1',
            className: '',
            shockType: 'global',
            shockName: 'All',
            reportName: 'active_pivot',
            cobDate: '2018-03-16',
            version: '1',
        },
        {
            files: null,
            oldDataSetId: 'appsets/marketrisk/active_pivot/global_stress/date=2018-03-23/version=1',
            newDataSetId:
                'shockType=global/shockName=All/reportName=active_pivot/cobDate=2018-03-23/version=1',
            className: '',
            shockType: 'global',
            shockName: 'All',
            reportName: 'active_pivot',
            cobDate: '2018-03-23',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/localised_stress/date=2018-03-16/version=1',
            newDataSetId:
                'shockType=localised/shockName=All/reportName=active_pivot/cobDate=2018-03-16/version=1',
            className: '',
            shockType: 'localised',
            shockName: 'All',
            reportName: 'active_pivot',
            cobDate: '2018-03-16',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/localised_stress/date=2018-03-23/version=1',
            newDataSetId:
                'shockType=localised/shockName=All/reportName=active_pivot/cobDate=2018-03-23/version=1',
            className: '',
            shockType: 'localised',
            shockName: 'All',
            reportName: 'active_pivot',
            cobDate: '2018-03-23',
            version: '1',
        },
    ],
    columns: [
        {
            columnName: 'shockType',
            displayName: 'Shock Type',
            allowFilter: true,
            allowSorting: true,
            className: 'reports__column',
            type: 'String',
        },
        {
            columnName: 'shockName',
            displayName: 'Shock Name',
            allowFilter: true,
            allowSorting: true,
            className: 'reports__column',
            type: 'String',
        },
        {
            columnName: 'reportName',
            displayName: 'Report Name',
            allowFilter: true,
            allowSorting: true,
            className: 'reports__column',
            type: 'String',
        },
        {
            columnName: 'cobDate',
            displayName: 'Cob Date',
            allowFilter: true,
            allowSorting: true,
            className: 'reports__column',
            type: 'Date',
        },
        {
            columnName: 'version',
            displayName: 'Version',
            allowFilter: true,
            allowSorting: true,
            className: 'reports__column',
            type: 'Integer',
        },
        {
            columnName: 'files',
            displayName: 'Files',
            allowFilter: false,
            allowSorting: false,
            className: 'reports-file__column reports__column',
            type: 'String',
        },
    ],
    viewname: 'Stress Testing',
    csvFileName: 'Stress_14 Sep 2018 17:23.csv',
};

export const sensitivityDsView = {
    columns: [
        {
            columnName: 'reportName',
            displayName: 'Report Name',
            allowFilter: true,
            allowSorting: true,
            className: 'reports__column',
            type: 'String',
        },
        {
            columnName: 'cobDate',
            displayName: 'Cob Date',
            allowFilter: true,
            allowSorting: true,
            className: 'reports__column',
            type: 'Date',
        },
        {
            columnName: 'version',
            displayName: 'Version',
            allowFilter: true,
            allowSorting: true,
            className: 'reports__column',
            type: 'Integer',
        },
        {
            columnName: 'files',
            displayName: 'Files',
            allowFilter: false,
            allowSorting: false,
            className: 'reports-file__column reports__column',
            type: 'String',
        },
    ],
    rows: [
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/sensitivities/reportName=active_pivot_exception_tickets/cobDate=2018-06-11/version=1',
            newDataSetId:
                'appsets/marketrisk/sensitivities/reportName=active_pivot_exception_tickets/cobDate=2018-06-11/version=1',
            className: 'reports__row',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-06-11',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/sensitivities/reportName=active_pivot_exception_tickets/cobDate=2018-06-15/version=1',
            newDataSetId:
                'appsets/marketrisk/sensitivities/reportName=active_pivot_exception_tickets/cobDate=2018-06-15/version=1',
            className: 'reports__row',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-06-15',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/sensitivities/reportName=active_pivot_exception_tickets/cobDate=2018-06-18/version=1',
            newDataSetId:
                'appsets/marketrisk/sensitivities/reportName=active_pivot_exception_tickets/cobDate=2018-06-18/version=1',
            className: 'reports__row',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-06-18',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/sensitivities/reportName=active_pivot_exception_tickets/cobDate=2018-06-19/version=1',
            newDataSetId:
                'appsets/marketrisk/sensitivities/reportName=active_pivot_exception_tickets/cobDate=2018-06-19/version=1',
            className: 'reports__row',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-06-19',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/sensitivities/reportName=active_pivot_exception_tickets/cobDate=2018-06-20/version=1',
            newDataSetId:
                'appsets/marketrisk/sensitivities/reportName=active_pivot_exception_tickets/cobDate=2018-06-20/version=1',
            className: 'reports__row',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-06-20',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/sensitivities/reportName=active_pivot_exception_tickets/cobDate=2018-06-21/version=1',
            newDataSetId:
                'appsets/marketrisk/sensitivities/reportName=active_pivot_exception_tickets/cobDate=2018-06-21/version=1',
            className: 'reports__row',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-06-21',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/sensitivities/reportName=active_pivot_exception_tickets/cobDate=2018-06-22/version=1',
            newDataSetId:
                'appsets/marketrisk/sensitivities/reportName=active_pivot_exception_tickets/cobDate=2018-06-22/version=1',
            className: 'reports__row',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-06-22',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/sensitivities/reportName=active_pivot_exception_tickets/cobDate=2018-07-01/version=1',
            newDataSetId:
                'appsets/marketrisk/sensitivities/reportName=active_pivot_exception_tickets/cobDate=2018-07-01/version=1',
            className: 'reports__row',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-07-01',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/sensitivities/reportName=active_pivot_exception_tickets/cobDate=2018-07-03/version=1',
            newDataSetId:
                'appsets/marketrisk/sensitivities/reportName=active_pivot_exception_tickets/cobDate=2018-07-03/version=1',
            className: 'reports__row',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-07-03',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/sensitivities/reportName=active_pivot_exception_tickets/cobDate=2018-07-08/version=1',
            newDataSetId:
                'appsets/marketrisk/sensitivities/reportName=active_pivot_exception_tickets/cobDate=2018-07-08/version=1',
            className: 'reports__row',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-07-08',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/sensitivities/reportName=active_pivot_exception_tickets/cobDate=2018-07-10/version=1',
            newDataSetId:
                'appsets/marketrisk/sensitivities/reportName=active_pivot_exception_tickets/cobDate=2018-07-10/version=1',
            className: 'reports__row',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-07-10',
            version: '1',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-01-25/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-01-25/version=1/shockName=date=2018-01-25',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-01-25',
            version: '1',
            shockName: 'date=2018-01-25',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-03-13/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-03-13/version=1/shockName=date=2018-03-13',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-03-13',
            version: '1',
            shockName: 'date=2018-03-13',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-03-15/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-03-15/version=1/shockName=date=2018-03-15',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-03-15',
            version: '1',
            shockName: 'date=2018-03-15',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-03-16/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-03-16/version=1/shockName=date=2018-03-16',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-03-16',
            version: '1',
            shockName: 'date=2018-03-16',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-03-20/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-03-20/version=1/shockName=date=2018-03-20',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-03-20',
            version: '1',
            shockName: 'date=2018-03-20',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-03-21/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-03-21/version=1/shockName=date=2018-03-21',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-03-21',
            version: '1',
            shockName: 'date=2018-03-21',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-03-22/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-03-22/version=1/shockName=date=2018-03-22',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-03-22',
            version: '1',
            shockName: 'date=2018-03-22',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-03-23/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-03-23/version=1/shockName=date=2018-03-23',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-03-23',
            version: '1',
            shockName: 'date=2018-03-23',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-03-26/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-03-26/version=1/shockName=date=2018-03-26',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-03-26',
            version: '1',
            shockName: 'date=2018-03-26',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-03-27/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-03-27/version=1/shockName=date=2018-03-27',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-03-27',
            version: '1',
            shockName: 'date=2018-03-27',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-03-28/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-03-28/version=1/shockName=date=2018-03-28',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-03-28',
            version: '1',
            shockName: 'date=2018-03-28',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-03-29/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-03-29/version=1/shockName=date=2018-03-29',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-03-29',
            version: '1',
            shockName: 'date=2018-03-29',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-03-30/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-03-30/version=1/shockName=date=2018-03-30',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-03-30',
            version: '1',
            shockName: 'date=2018-03-30',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-02/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-04-02/version=1/shockName=date=2018-04-02',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-04-02',
            version: '1',
            shockName: 'date=2018-04-02',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-03/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-04-03/version=1/shockName=date=2018-04-03',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-04-03',
            version: '1',
            shockName: 'date=2018-04-03',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-04/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-04-04/version=1/shockName=date=2018-04-04',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-04-04',
            version: '1',
            shockName: 'date=2018-04-04',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-05/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-04-05/version=1/shockName=date=2018-04-05',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-04-05',
            version: '1',
            shockName: 'date=2018-04-05',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-06/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-04-06/version=1/shockName=date=2018-04-06',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-04-06',
            version: '1',
            shockName: 'date=2018-04-06',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-09/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-04-09/version=1/shockName=date=2018-04-09',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-04-09',
            version: '1',
            shockName: 'date=2018-04-09',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-10/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-04-10/version=1/shockName=date=2018-04-10',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-04-10',
            version: '1',
            shockName: 'date=2018-04-10',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-11/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-04-11/version=1/shockName=date=2018-04-11',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-04-11',
            version: '1',
            shockName: 'date=2018-04-11',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-12/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-04-12/version=1/shockName=date=2018-04-12',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-04-12',
            version: '1',
            shockName: 'date=2018-04-12',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-13/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-04-13/version=1/shockName=date=2018-04-13',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-04-13',
            version: '1',
            shockName: 'date=2018-04-13',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-16/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-04-16/version=1/shockName=date=2018-04-16',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-04-16',
            version: '1',
            shockName: 'date=2018-04-16',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-17/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-04-17/version=1/shockName=date=2018-04-17',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-04-17',
            version: '1',
            shockName: 'date=2018-04-17',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-18/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-04-18/version=1/shockName=date=2018-04-18',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-04-18',
            version: '1',
            shockName: 'date=2018-04-18',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-19/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-04-19/version=1/shockName=date=2018-04-19',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-04-19',
            version: '1',
            shockName: 'date=2018-04-19',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-20/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-04-20/version=1/shockName=date=2018-04-20',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-04-20',
            version: '1',
            shockName: 'date=2018-04-20',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-23/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-04-23/version=1/shockName=date=2018-04-23',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-04-23',
            version: '1',
            shockName: 'date=2018-04-23',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-24/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-04-24/version=1/shockName=date=2018-04-24',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-04-24',
            version: '1',
            shockName: 'date=2018-04-24',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-25/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-04-25/version=1/shockName=date=2018-04-25',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-04-25',
            version: '1',
            shockName: 'date=2018-04-25',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-26/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-04-26/version=1/shockName=date=2018-04-26',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-04-26',
            version: '1',
            shockName: 'date=2018-04-26',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-27/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-04-27/version=1/shockName=date=2018-04-27',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-04-27',
            version: '1',
            shockName: 'date=2018-04-27',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-05-06/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-05-06/version=1/shockName=date=2018-05-06',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-05-06',
            version: '1',
            shockName: 'date=2018-05-06',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-05-07/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-05-07/version=1/shockName=date=2018-05-07',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-05-07',
            version: '1',
            shockName: 'date=2018-05-07',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-05-08/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-05-08/version=1/shockName=date=2018-05-08',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-05-08',
            version: '1',
            shockName: 'date=2018-05-08',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-05-09/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-05-09/version=1/shockName=date=2018-05-09',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-05-09',
            version: '1',
            shockName: 'date=2018-05-09',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-05-10/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-05-10/version=1/shockName=date=2018-05-10',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-05-10',
            version: '1',
            shockName: 'date=2018-05-10',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-05-14/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-05-14/version=1/shockName=date=2018-05-14',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-05-14',
            version: '1',
            shockName: 'date=2018-05-14',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-05-16/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-05-16/version=1/shockName=date=2018-05-16',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-05-16',
            version: '1',
            shockName: 'date=2018-05-16',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-05-17/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-05-17/version=1/shockName=date=2018-05-17',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-05-17',
            version: '1',
            shockName: 'date=2018-05-17',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-05-22/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-05-22/version=1/shockName=date=2018-05-22',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-05-22',
            version: '1',
            shockName: 'date=2018-05-22',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-05-23/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-05-23/version=1/shockName=date=2018-05-23',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-05-23',
            version: '1',
            shockName: 'date=2018-05-23',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-06-07/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-06-07/version=1/shockName=date=2018-06-07',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-06-07',
            version: '1',
            shockName: 'date=2018-06-07',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-06-08/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-06-08/version=1/shockName=date=2018-06-08',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-06-08',
            version: '1',
            shockName: 'date=2018-06-08',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-06-11/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-06-11/version=1/shockName=date=2018-06-11',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-06-11',
            version: '1',
            shockName: 'date=2018-06-11',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-06-12/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-06-12/version=1/shockName=date=2018-06-12',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-06-12',
            version: '1',
            shockName: 'date=2018-06-12',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-06-13/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-06-13/version=1/shockName=date=2018-06-13',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-06-13',
            version: '1',
            shockName: 'date=2018-06-13',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-06-14/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-06-14/version=1/shockName=date=2018-06-14',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-06-14',
            version: '1',
            shockName: 'date=2018-06-14',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-06-21/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-06-21/version=1/shockName=date=2018-06-21',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-06-21',
            version: '1',
            shockName: 'date=2018-06-21',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-06-22/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-06-22/version=1/shockName=date=2018-06-22',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-06-22',
            version: '1',
            shockName: 'date=2018-06-22',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-06-25/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-06-25/version=1/shockName=date=2018-06-25',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-06-25',
            version: '1',
            shockName: 'date=2018-06-25',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-06-26/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-06-26/version=1/shockName=date=2018-06-26',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-06-26',
            version: '1',
            shockName: 'date=2018-06-26',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-06-27/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-06-27/version=1/shockName=date=2018-06-27',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-06-27',
            version: '1',
            shockName: 'date=2018-06-27',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-06-28/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-06-28/version=1/shockName=date=2018-06-28',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-06-28',
            version: '1',
            shockName: 'date=2018-06-28',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-07-02/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-07-02/version=1/shockName=date=2018-07-02',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-07-02',
            version: '1',
            shockName: 'date=2018-07-02',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-07-03/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-07-03/version=1/shockName=date=2018-07-03',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-07-03',
            version: '1',
            shockName: 'date=2018-07-03',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-07-04/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-07-04/version=1/shockName=date=2018-07-04',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-07-04',
            version: '1',
            shockName: 'date=2018-07-04',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-07-05/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-07-05/version=1/shockName=date=2018-07-05',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-07-05',
            version: '1',
            shockName: 'date=2018-07-05',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-07-08/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-07-08/version=1/shockName=date=2018-07-08',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-07-08',
            version: '1',
            shockName: 'date=2018-07-08',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-07-09/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-07-09/version=1/shockName=date=2018-07-09',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-07-09',
            version: '1',
            shockName: 'date=2018-07-09',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-07-10/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-07-10/version=1/shockName=date=2018-07-10',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-07-10',
            version: '1',
            shockName: 'date=2018-07-10',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-07-11/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-07-11/version=1/shockName=date=2018-07-11',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-07-11',
            version: '1',
            shockName: 'date=2018-07-11',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-07-12/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-07-12/version=1/shockName=date=2018-07-12',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-07-12',
            version: '1',
            shockName: 'date=2018-07-12',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-07-15/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-07-15/version=1/shockName=date=2018-07-15',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-07-15',
            version: '1',
            shockName: 'date=2018-07-15',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-08-10/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-08-10/version=1/shockName=date=2018-08-10',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-08-10',
            version: '1',
            shockName: 'date=2018-08-10',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-08-13/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-08-13/version=1/shockName=date=2018-08-13',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-08-13',
            version: '1',
            shockName: 'date=2018-08-13',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-08-14/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-08-14/version=1/shockName=date=2018-08-14',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-08-14',
            version: '1',
            shockName: 'date=2018-08-14',
        },
        {
            files: null,
            oldDataSetId:
                'appsets/marketrisk/active_pivot/exception_tickets/date=2018-08-15/version=1',
            newDataSetId:
                'reportName=active_pivot_exception_tickets/cobDate=2018-08-15/version=1/shockName=date=2018-08-15',
            className: '',
            reportName: 'active_pivot_exception_tickets',
            cobDate: '2018-08-15',
            version: '1',
            shockName: 'date=2018-08-15',
        },
        {
            files: null,
            oldDataSetId: 'appsets/marketrisk/active_pivot/sensitivities/date=2018-01-25/version=1',
            newDataSetId:
                'reportName=active_pivot_sensitivites/cobDate=2018-01-25/version=1/shockName=date=2018-01-25',
            className: '',
            reportName: 'active_pivot_sensitivites',
            cobDate: '2018-01-25',
            version: '1',
            shockName: 'date=2018-01-25',
        },
        {
            files: null,
            oldDataSetId: 'appsets/marketrisk/active_pivot/sensitivities/date=2018-03-16/version=1',
            newDataSetId:
                'reportName=active_pivot_sensitivites/cobDate=2018-03-16/version=1/shockName=date=2018-03-16',
            className: '',
            reportName: 'active_pivot_sensitivites',
            cobDate: '2018-03-16',
            version: '1',
            shockName: 'date=2018-03-16',
        },
        {
            files: null,
            oldDataSetId: 'appsets/marketrisk/active_pivot/sensitivities/date=2018-03-20/version=1',
            newDataSetId:
                'reportName=active_pivot_sensitivites/cobDate=2018-03-20/version=1/shockName=date=2018-03-20',
            className: '',
            reportName: 'active_pivot_sensitivites',
            cobDate: '2018-03-20',
            version: '1',
            shockName: 'date=2018-03-20',
        },
        {
            files: null,
            oldDataSetId: 'appsets/marketrisk/active_pivot/sensitivities/date=2018-03-23/version=1',
            newDataSetId:
                'reportName=active_pivot_sensitivites/cobDate=2018-03-23/version=1/shockName=date=2018-03-23',
            className: '',
            reportName: 'active_pivot_sensitivites',
            cobDate: '2018-03-23',
            version: '1',
            shockName: 'date=2018-03-23',
        },
        {
            files: null,
            oldDataSetId: 'appsets/marketrisk/active_pivot/sensitivities/date=2018-04-05/version=1',
            newDataSetId:
                'reportName=active_pivot_sensitivites/cobDate=2018-04-05/version=1/shockName=date=2018-04-05',
            className: '',
            reportName: 'active_pivot_sensitivites',
            cobDate: '2018-04-05',
            version: '1',
            shockName: 'date=2018-04-05',
        },
    ],
    viewname: 'Sensitivity',
    csvFileName: 'Sensitivity.csv',
};
