export default [
    {
        dataSetId: 'appsets/marketrisk/stress/errors/localised/date=2018-03-16/version=1',
        modificationTime: '2018-05-15T13:22:53Z',
    },
    {
        dataSetId: 'appsets/marketrisk/stress/errors/localised/date=2018-03-23/version=1',
        modificationTime: '2018-04-04T15:01:15Z',
    },
    {
        dataSetId: 'appsets/marketrisk/stress/fallback/global/runDate=2018-02-26/version=1',
        modificationTime: '2018-03-29T12:34:19Z',
    },
    {
        dataSetId: 'appsets/marketrisk/stress/fallback/global/date=2018-03-16/version=1',
        modificationTime: '2018-05-15T13:12:34Z',
    },
    {
        dataSetId: 'appsets/marketrisk/stress/fallback/global/date=2018-03-23/version=1',
        modificationTime: '2018-04-04T14:36:03Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/fdsf/shockType=FX/shockName=FDSF/reportName=error/cobDate=2018-06-29/version=1',
        modificationTime: '2018-09-11T10:36:19Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/fdsf/shockType=FX/shockName=FDSF/reportName=trades/cobDate=2018-06-29/version=1',
        modificationTime: '2018-09-11T10:36:13Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/fdsf/shockType=IR/shockName=FDSF/reportName=aggregate/cobDate=2018-06-29/version=1',
        modificationTime: '2018-09-11T10:37:13Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/fdsf/shockType=IR/shockName=FDSF/reportName=error/runDate=2018-06-29/version=1',
        modificationTime: '2018-09-11T10:36:25Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/fdsf/shockType=IR/shockName=FDSF/reportName=trades/cobDate=2018-06-29/version=1',
        modificationTime: '2018-09-11T10:36:15Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/global/Acrimonious_Brexit_Triggers_Global_Risk_Aversion/date=2018-03-16/version=1',
        modificationTime: '2018-04-13T00:43:33Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/global/Acrimonious_Brexit_Triggers_Global_Risk_Aversion/date=2018-03-23/version=1',
        modificationTime: '2018-04-04T14:53:16Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/global/Acrimonious_Brexit_Triggers_Global_Risk_Aversion-20180223022915/date=2018-03-16/version=1',
        modificationTime: '2018-04-04T16:40:02Z',
    },
    {
        dataSetId: 'appsets/marketrisk/stress/global/Bond_Armageddon/date=2018-03-23/version=1',
        modificationTime: '2018-04-04T14:54:29Z',
    },
    {
        dataSetId: 'appsets/marketrisk/stress/global/BrexitGlobalShock/date=2018-03-16/version=1',
        modificationTime: '2018-04-04T16:38:30Z',
    },
    {
        dataSetId: 'appsets/marketrisk/stress/global/Middle_East_War/date=2018-03-23/version=1',
        modificationTime: '2018-04-04T14:51:51Z',
    },
    {
        dataSetId: 'appsets/marketrisk/stress/global/Oil_Price_Slump/date=2018-03-23/version=1',
        modificationTime: '2018-04-04T14:52:44Z',
    },
    {
        dataSetId: 'appsets/marketrisk/stress/global/Oil_Price_Spike/date=2018-03-23/version=1',
        modificationTime: '2018-04-04T14:50:50Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/global/consolidated_desk/date=2017-10-19/version=1/blobs',
        modificationTime: '2017-11-07T15:34:36Z',
    },
    {
        dataSetId: 'appsets/marketrisk/stress/global/consolidated_desk/date=2018-03-16/version=1',
        modificationTime: '2018-04-13T00:52:43Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/global-missingshocks/Acrimonious_Brexit_Triggers_Global_Risk_Aversion/date=2018-03-16/version=1',
        modificationTime: '2018-04-13T00:36:12Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/global-missingshocks/Acrimonious_Brexit_Triggers_Global_Risk_Aversion/date=2018-03-23/version=1',
        modificationTime: '2018-04-04T15:09:52Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/global-missingshocks/Acrimonious_Brexit_Triggers_Global_Risk_Aversion-20180223022915/date=2018-03-16/version=1',
        modificationTime: '2018-04-04T16:25:55Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/global-missingshocks/Bond_Armageddon/date=2018-03-23/version=1',
        modificationTime: '2018-04-04T15:09:51Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/global-missingshocks/Middle_East_Scn/date=2018-03-16/version=1',
        modificationTime: '2018-04-13T00:36:11Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/global-missingshocks/Middle_East_War/date=2018-03-23/version=1',
        modificationTime: '2018-04-04T15:09:51Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/global-missingshocks/Oil_Price_Slump/date=2018-03-23/version=1',
        modificationTime: '2018-04-04T15:09:52Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/global-missingshocks/Oil_Price_Spike/date=2018-03-23/version=1',
        modificationTime: '2018-04-04T15:09:52Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/localised/LOCALISED_FX_SPOT/date=2018-03-16/version=1',
        modificationTime: '2018-04-13T01:31:18Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/localised/LOCALISED_FX_SPOT/date=2018-03-23/version=1',
        modificationTime: '2018-04-04T14:58:51Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/localised/LOCALISED_FX_SPOT-20180302151912/date=2018-03-16/version=1',
        modificationTime: '2018-04-05T06:56:26Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/localised/LOCALISED_FX_SPOT_VOLS/date=2018-03-16/version=1',
        modificationTime: '2018-05-15T13:16:06Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/localised/LOCALISED_FX_SPOT_VOLS/date=2018-03-23/version=1',
        modificationTime: '2018-04-04T14:58:38Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/localised/LOCALISED_FX_SPOT_VOLS-20180302152014/date=2018-03-16/version=1',
        modificationTime: '2018-04-05T06:56:55Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/localised/LOCALISED_FX_SPOT_VOLS_RR/date=2018-03-16/version=1',
        modificationTime: '2018-04-13T01:31:17Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/localised/LOCALISED_FX_SPOT_VOLS_RR-20180305121521/date=2018-03-16/version=1',
        modificationTime: '2018-04-05T06:57:11Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/localised/LocalisedIRCurveAndVolShocks/date=2018-03-16/version=1',
        modificationTime: '2018-04-13T01:31:15Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/localised/LocalisedIRCurveAndVolShocks_Region/date=2018-03-16/version=1',
        modificationTime: '2018-04-13T01:31:37Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/localised-missingshocks/LOCALISED_FX_SPOT/date=2018-03-16/version=1',
        modificationTime: '2018-04-13T00:44:46Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/localised-missingshocks/LOCALISED_FX_SPOT/date=2018-03-23/version=1',
        modificationTime: '2018-04-04T15:12:32Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/localised-missingshocks/LOCALISED_FX_SPOT_VOLS/date=2018-03-16/version=1',
        modificationTime: '2018-05-15T13:14:24Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/localised-missingshocks/LocalisedIRCurveAndVolShocks_Region/date=2018-03-16/version=1',
        modificationTime: '2018-04-13T00:44:48Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/shockType=global/Acrimonious_Brexit_Triggers_Global_Risk_Aversion/cobDate=2018-03-23/version=1',
        modificationTime: '2018-06-16T20:19:35Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/shockType=global/Bond_Armageddon/cobDate=2018-03-23/version=1',
        modificationTime: '2018-06-16T20:20:57Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/shockType=global/Middle_East_War/cobDate=2018-03-23/version=1',
        modificationTime: '2018-06-16T20:20:03Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/shockType=global/shockName=Acrimonious_Brexit_Triggers_Global_Risk_Aversion/reportName=trades/cobDate=2018-03-23/version=1',
        modificationTime: '2018-06-16T20:31:12Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/shockType=global/shockName=Bond_Armageddon/reportName=trades/cobDate=2018-03-23/version=1',
        modificationTime: '2018-06-16T20:32:42Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/shockType=global/shockName=Middle_East_War/reportName=trades/cobDate=2018-03-23/version=1',
        modificationTime: '2018-06-16T20:31:40Z',
    },
    {
        dataSetId:
            'appsets/marketrisk/stress/shockType=global/shockName=Oil_Price_Spike/reportName=trades/cobDate=2018-03-23/version=1',
        modificationTime: '2018-06-16T20:30:36Z',
    },
    {
        dataSetId: 'appsets/marketrisk/stress/summary/batch/date=2018-03-16/version=1',
        modificationTime: '2018-05-15T13:30:26Z',
    },
    {
        dataSetId: 'appsets/marketrisk/stress/summary/performance/date=2018-03-16/version=1',
        modificationTime: '2018-05-15T13:33:35Z',
    },
    {
        dataSetId: 'appsets/marketrisk/stress/summary/sensitivity/date=2018-03-16/version=1',
        modificationTime: '2018-05-15T13:32:31Z',
    },
];

export const mockRespWithArray = [
    {
        rootPath: 'appsets/marketrisk/stress',
        dataSetList: [
            {
                dataSetId: 'appsets/marketrisk/stress/errors/global/date=2018-02-26/version=1',
                modificationTime: '2018-03-29T12:32:57Z',
            },
            {
                dataSetId: 'appsets/marketrisk/stress/errors/global/date=2018-03-16/version=1',
                modificationTime: '2018-05-15T13:15:57Z',
            },
            {
                dataSetId: 'appsets/marketrisk/stress/errors/global/date=2018-03-23/version=1',
                modificationTime: '2018-04-04T14:44:49Z',
            },
            {
                dataSetId: 'appsets/marketrisk/stress/errors/localised/date=2018-03-16/version=1',
                modificationTime: '2018-05-15T13:22:53Z',
            },
            {
                dataSetId: 'appsets/marketrisk/stress/errors/localised/date=2018-03-23/version=1',
                modificationTime: '2018-04-04T15:01:15Z',
            },
            {
                dataSetId: 'appsets/marketrisk/stress/fallback/global/date=2018-02-26/version=1',
                modificationTime: '2018-03-29T12:34:19Z',
            },
            {
                dataSetId: 'appsets/marketrisk/stress/fallback/global/date=2018-03-16/version=1',
                modificationTime: '2018-05-15T13:12:34Z',
            },
            {
                dataSetId: 'appsets/marketrisk/stress/fallback/global/date=2018-03-23/version=1',
                modificationTime: '2018-04-04T14:36:03Z',
            },
            {
                dataSetId: 'appsets/marketrisk/stress/fallback/localised/date=2018-03-16/version=1',
                modificationTime: '2018-05-15T13:19:55Z',
            },
            {
                dataSetId: 'appsets/marketrisk/stress/fallback/localised/date=2018-03-23/version=1',
                modificationTime: '2018-04-04T14:58:27Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/fdsf/shockType=FX/shockName=FDSF/reportName=aggregate/cobDate=2018-06-29/version=1',
                modificationTime: '2018-09-11T10:37:13Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/fdsf/shockType=FX/shockName=FDSF/reportName=error/cobDate=2018-06-29/version=1',
                modificationTime: '2018-09-11T10:36:19Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/fdsf/shockType=FX/shockName=FDSF/reportName=trades/cobDate=2018-06-29/version=1',
                modificationTime: '2018-09-11T10:36:13Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/fdsf/shockType=IR/shockName=FDSF/reportName=aggregate/cobDate=2018-06-29/version=1',
                modificationTime: '2018-09-11T10:37:13Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/fdsf/shockType=IR/shockName=FDSF/reportName=error/cobDate=2018-06-29/version=1',
                modificationTime: '2018-09-11T10:36:25Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/fdsf/shockType=IR/shockName=FDSF/reportName=trades/cobDate=2018-06-29/version=1',
                modificationTime: '2018-09-11T10:36:15Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/global/Acrimonious_Brexit_Triggers_Global_Risk_Aversion/date=2018-03-16/version=1',
                modificationTime: '2018-04-13T00:43:33Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/global/Acrimonious_Brexit_Triggers_Global_Risk_Aversion/date=2018-03-23/version=1',
                modificationTime: '2018-04-04T14:53:16Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/global/Acrimonious_Brexit_Triggers_Global_Risk_Aversion-20180223022915/date=2018-03-16/version=1',
                modificationTime: '2018-04-04T16:40:02Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/global/Bond_Armageddon/date=2018-03-23/version=1',
                modificationTime: '2018-04-04T14:54:29Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/global/BrexitGlobalShock/date=2018-03-16/version=1',
                modificationTime: '2018-04-04T16:38:30Z',
            },
            {
                dataSetId: 'appsets/marketrisk/stress/global/CNY/date=2018-03-16/version=1',
                modificationTime: '2018-05-15T13:13:21Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/global/CNY-20180223022948/date=2018-03-16/version=1',
                modificationTime: '2018-04-04T16:39:05Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/global/Middle_East_Scn/date=2018-03-16/version=1',
                modificationTime: '2018-04-13T00:43:31Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/global/Middle_East_War/date=2018-03-23/version=1',
                modificationTime: '2018-04-04T14:51:51Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/global/Oil_Price_Slump/date=2018-03-23/version=1',
                modificationTime: '2018-04-04T14:52:44Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/global/Oil_Price_Spike/date=2018-03-23/version=1',
                modificationTime: '2018-04-04T14:50:50Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/global/consolidated_desk/date=2017-10-19/version=1/blobs',
                modificationTime: '2017-11-07T15:34:36Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/global/consolidated_desk/date=2018-03-16/version=1',
                modificationTime: '2018-04-13T00:52:43Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/global-missingshocks/Acrimonious_Brexit_Triggers_Global_Risk_Aversion/date=2018-03-16/version=1',
                modificationTime: '2018-04-13T00:36:12Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/global-missingshocks/Acrimonious_Brexit_Triggers_Global_Risk_Aversion/date=2018-03-23/version=1',
                modificationTime: '2018-04-04T15:09:52Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/global-missingshocks/Acrimonious_Brexit_Triggers_Global_Risk_Aversion-20180223022915/date=2018-03-16/version=1',
                modificationTime: '2018-04-04T16:25:55Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/global-missingshocks/Bond_Armageddon/date=2018-03-23/version=1',
                modificationTime: '2018-04-04T15:09:51Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/global-missingshocks/BrexitGlobalShock/date=2018-03-16/version=1',
                modificationTime: '2018-04-04T16:25:56Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/global-missingshocks/CNY/date=2018-03-16/version=1',
                modificationTime: '2018-05-15T13:11:24Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/global-missingshocks/CNY-20180223022948/date=2018-03-16/version=1',
                modificationTime: '2018-04-04T16:25:57Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/global-missingshocks/Middle_East_Scn/date=2018-03-16/version=1',
                modificationTime: '2018-04-13T00:36:11Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/global-missingshocks/Middle_East_War/date=2018-03-23/version=1',
                modificationTime: '2018-04-04T15:09:51Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/global-missingshocks/Oil_Price_Slump/date=2018-03-23/version=1',
                modificationTime: '2018-04-04T15:09:52Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/global-missingshocks/Oil_Price_Spike/date=2018-03-23/version=1',
                modificationTime: '2018-04-04T15:09:52Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/localised/LOCALISED_FX_SPOT/date=2018-03-16/version=1',
                modificationTime: '2018-04-13T01:31:18Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/localised/LOCALISED_FX_SPOT/date=2018-03-23/version=1',
                modificationTime: '2018-04-04T14:58:51Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/localised/LOCALISED_FX_SPOT-20180302151912/date=2018-03-16/version=1',
                modificationTime: '2018-04-05T06:56:26Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/localised/LOCALISED_FX_SPOT_VOLS/date=2018-03-16/version=1',
                modificationTime: '2018-05-15T13:16:06Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/localised/LOCALISED_FX_SPOT_VOLS/date=2018-03-23/version=1',
                modificationTime: '2018-04-04T14:58:38Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/localised/LOCALISED_FX_SPOT_VOLS-20180302152014/date=2018-03-16/version=1',
                modificationTime: '2018-04-05T06:56:55Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/localised/LOCALISED_FX_SPOT_VOLS_RR/date=2018-03-16/version=1',
                modificationTime: '2018-04-13T01:31:17Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/localised/LOCALISED_FX_SPOT_VOLS_RR-20180305121521/date=2018-03-16/version=1',
                modificationTime: '2018-04-05T06:57:11Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/localised/LocalisedIRCurveAndVolShocks/date=2018-03-16/version=1',
                modificationTime: '2018-04-13T01:31:15Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/localised/LocalisedIRCurveAndVolShocks_Region/date=2018-03-16/version=1',
                modificationTime: '2018-04-13T01:31:37Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/localised/Localised_Stress_Commodities/date=2018-03-16/version=1',
                modificationTime: '2018-04-13T01:31:34Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/localised/SPT_Rates_Supplementary/date=2018-03-23/version=1',
                modificationTime: '2018-04-04T14:58:48Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/localised/TestLMMshift/date=2018-03-16/version=1',
                modificationTime: '2018-04-13T01:31:30Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/localised-missingshocks/LOCALISED_FX_SPOT/date=2018-03-16/version=1',
                modificationTime: '2018-04-13T00:44:46Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/localised-missingshocks/LOCALISED_FX_SPOT/date=2018-03-23/version=1',
                modificationTime: '2018-04-04T15:12:32Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/localised-missingshocks/LOCALISED_FX_SPOT_VOLS/date=2018-03-16/version=1',
                modificationTime: '2018-05-15T13:14:24Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/localised-missingshocks/LOCALISED_FX_SPOT_VOLS/date=2018-03-23/version=1',
                modificationTime: '2018-04-04T15:12:30Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/localised-missingshocks/LOCALISED_FX_SPOT_VOLS_RR/date=2018-03-16/version=1',
                modificationTime: '2018-04-13T00:44:45Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/localised-missingshocks/LocalisedIRCurveAndVolShocks/date=2018-03-16/version=1',
                modificationTime: '2018-04-13T00:44:44Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/localised-missingshocks/LocalisedIRCurveAndVolShocks_Region/date=2018-03-16/version=1',
                modificationTime: '2018-04-13T00:44:48Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/localised-missingshocks/Localised_Stress_Commodities/date=2018-03-16/version=1',
                modificationTime: '2018-04-13T00:44:48Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/localised-missingshocks/SPT_Rates_Supplementary/date=2018-03-23/version=1',
                modificationTime: '2018-04-04T15:12:31Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/localised-missingshocks/TestLMMshift/date=2018-03-16/version=1',
                modificationTime: '2018-04-13T00:44:47Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/shockType=global/Acrimonious_Brexit_Triggers_Global_Risk_Aversion/cobDate=2018-03-23/version=1',
                modificationTime: '2018-06-16T20:19:35Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/shockType=global/Bond_Armageddon/cobDate=2018-03-23/version=1',
                modificationTime: '2018-06-16T20:20:57Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/shockType=global/Middle_East_War/cobDate=2018-03-23/version=1',
                modificationTime: '2018-06-16T20:20:03Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/shockType=global/Oil_Price_Slump/cobDate=2018-03-23/version=1',
                modificationTime: '2018-06-16T20:20:28Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/shockType=global/Oil_Price_Spike/cobDate=2018-03-23/version=1',
                modificationTime: '2018-06-16T20:18:59Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/shockType=global/shockName=Acrimonious_Brexit_Triggers_Global_Risk_Aversion/reportName=trades/cobDate=2018-03-23/version=1',
                modificationTime: '2018-06-16T20:31:12Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/shockType=global/shockName=Bond_Armageddon/reportName=trades/cobDate=2018-03-23/version=1',
                modificationTime: '2018-06-16T20:32:42Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/shockType=global/shockName=Middle_East_War/reportName=trades/cobDate=2018-03-23/version=1',
                modificationTime: '2018-06-16T20:31:40Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/shockType=global/shockName=Oil_Price_Slump/reportName=trades/cobDate=2018-03-23/version=1',
                modificationTime: '2018-06-16T20:32:13Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/shockType=global/shockName=Oil_Price_Spike/reportName=trades/cobDate=2018-03-23/version=1',
                modificationTime: '2018-06-16T20:30:36Z',
            },
            {
                dataSetId: 'appsets/marketrisk/stress/summary/batch/date=2018-03-16/version=1',
                modificationTime: '2018-05-15T13:30:26Z',
            },
            {
                dataSetId: 'appsets/marketrisk/stress/summary/batch/date=2018-03-23/version=1',
                modificationTime: '2018-04-12T17:06:43Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/summary/performance/date=2018-03-16/version=1',
                modificationTime: '2018-05-15T13:33:35Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/stress/summary/sensitivity/date=2018-03-16/version=1',
                modificationTime: '2018-05-15T13:32:31Z',
            },
        ],
    },
    {
        rootPath: '',
        dataSetList: [
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-01-25/version=1',
                modificationTime: '2018-03-05T17:23:18Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-03-13/version=1',
                modificationTime: '2018-03-14T00:21:31Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-03-15/version=1',
                modificationTime: '2018-03-16T00:23:12Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-03-16/version=1',
                modificationTime: '2018-05-15T12:11:28Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-03-20/version=1',
                modificationTime: '2018-04-05T10:06:19Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-03-21/version=1',
                modificationTime: '2018-03-22T00:21:36Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-03-22/version=1',
                modificationTime: '2018-03-23T00:22:24Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-03-23/version=1',
                modificationTime: '2018-04-04T11:44:09Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-03-26/version=1',
                modificationTime: '2018-03-27T00:31:29Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-03-27/version=1',
                modificationTime: '2018-03-28T00:33:00Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-03-28/version=1',
                modificationTime: '2018-03-29T00:33:05Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-03-29/version=1',
                modificationTime: '2018-03-30T00:33:56Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-03-30/version=1',
                modificationTime: '2018-03-31T00:33:00Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-02/version=1',
                modificationTime: '2018-04-03T00:33:47Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-03/version=1',
                modificationTime: '2018-04-04T00:34:30Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-04/version=1',
                modificationTime: '2018-04-05T00:35:21Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-05/version=1',
                modificationTime: '2018-04-09T12:28:26Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-06/version=1',
                modificationTime: '2018-04-07T00:34:07Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-09/version=1',
                modificationTime: '2018-04-10T00:34:36Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-10/version=1',
                modificationTime: '2018-04-11T00:35:34Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-11/version=1',
                modificationTime: '2018-04-12T00:36:46Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-12/version=1',
                modificationTime: '2018-04-13T00:51:22Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-13/version=1',
                modificationTime: '2018-04-14T00:38:59Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-16/version=1',
                modificationTime: '2018-04-17T00:37:53Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-17/version=1',
                modificationTime: '2018-04-18T00:37:10Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-18/version=1',
                modificationTime: '2018-04-19T00:38:04Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-19/version=1',
                modificationTime: '2018-04-20T00:39:38Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-20/version=1',
                modificationTime: '2018-04-21T00:38:47Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-23/version=1',
                modificationTime: '2018-04-24T00:38:18Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-24/version=1',
                modificationTime: '2018-04-25T00:38:41Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-25/version=1',
                modificationTime: '2018-04-26T00:40:36Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-26/version=1',
                modificationTime: '2018-05-28T07:21:00Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-04-27/version=1',
                modificationTime: '2018-04-28T00:40:15Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-05-06/version=1',
                modificationTime: '2018-05-31T03:26:37Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-05-07/version=1',
                modificationTime: '2018-05-31T02:32:08Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-05-08/version=1',
                modificationTime: '2018-05-31T07:06:06Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-05-09/version=1',
                modificationTime: '2018-05-10T00:41:31Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-05-10/version=1',
                modificationTime: '2018-05-11T00:42:54Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-05-14/version=1',
                modificationTime: '2018-05-15T00:37:12Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-05-16/version=1',
                modificationTime: '2018-05-17T00:39:41Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-05-17/version=1',
                modificationTime: '2018-05-18T00:40:24Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-05-22/version=1',
                modificationTime: '2018-05-23T00:39:52Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-05-23/version=1',
                modificationTime: '2018-05-24T00:40:19Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-06-07/version=1',
                modificationTime: '2018-06-08T00:09:32Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-06-08/version=1',
                modificationTime: '2018-06-09T00:11:11Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-06-11/version=1',
                modificationTime: '2018-06-12T00:23:15Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-06-12/version=1',
                modificationTime: '2018-06-13T00:11:22Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-06-13/version=1',
                modificationTime: '2018-06-14T00:13:10Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-06-14/version=1',
                modificationTime: '2018-06-15T00:11:09Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-06-21/version=1',
                modificationTime: '2018-08-09T12:31:37Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-06-22/version=1',
                modificationTime: '2018-08-09T12:42:32Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-06-25/version=1',
                modificationTime: '2018-08-09T12:58:49Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-06-26/version=1',
                modificationTime: '2018-06-27T22:03:59Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-06-27/version=1',
                modificationTime: '2018-06-28T22:04:20Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-06-28/version=1',
                modificationTime: '2018-06-29T22:03:59Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-07-02/version=1',
                modificationTime: '2018-07-03T22:03:32Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-07-03/version=1',
                modificationTime: '2018-07-04T22:04:48Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-07-04/version=1',
                modificationTime: '2018-07-05T22:03:48Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-07-05/version=1',
                modificationTime: '2018-07-06T22:03:46Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-07-08/version=1',
                modificationTime: '2018-07-09T22:03:29Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-07-09/version=1',
                modificationTime: '2018-07-10T22:02:18Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-07-10/version=1',
                modificationTime: '2018-07-11T22:02:39Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-07-11/version=1',
                modificationTime: '2018-07-12T22:02:33Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-07-12/version=1',
                modificationTime: '2018-07-13T22:02:43Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-07-15/version=1',
                modificationTime: '2018-07-16T22:04:50Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-08-10/version=1',
                modificationTime: '2018-08-10T21:00:35Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-08-13/version=1',
                modificationTime: '2018-08-13T21:02:23Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-08-14/version=1',
                modificationTime: '2018-08-14T21:02:45Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/exception_tickets/date=2018-08-15/version=1',
                modificationTime: '2018-08-15T21:03:48Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/global_stress/date=2018-03-16/version=1',
                modificationTime: '2018-05-15T13:23:39Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/global_stress/date=2018-03-23/version=1',
                modificationTime: '2018-04-09T10:53:58Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/localised_stress/date=2018-03-16/version=1',
                modificationTime: '2018-05-15T13:25:01Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/localised_stress/date=2018-03-23/version=1',
                modificationTime: '2018-04-04T15:04:41Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/sensitivities/date=2018-01-25/version=1',
                modificationTime: '2018-03-05T17:26:10Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/sensitivities/date=2018-03-16/version=1',
                modificationTime: '2018-05-15T12:22:40Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/sensitivities/date=2018-03-20/version=1',
                modificationTime: '2018-04-05T10:04:11Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/sensitivities/date=2018-03-23/version=1',
                modificationTime: '2018-04-04T12:16:16Z',
            },
            {
                dataSetId:
                    'appsets/marketrisk/active_pivot/sensitivities/date=2018-04-05/version=1',
                modificationTime: '2018-04-09T12:25:59Z',
            },
        ],
    },
];

export const datasetDetails = {
    modificationTime: '2018-04-04T15:09:52Z',
    chunks: [],
    dataSetId:
        'appsets/marketrisk/stress/global-missingshocks/Oil_Price_Spike/date=2018-03-23/version=1',
    blobs: [{ name: 'Oil_Price_Spike-Global-MissingShocks-20180323.csv.gz', sizeInBytes: 131998 }],
    metadata: {
        appName:
            'com.scb.sabre.store.job.feed.globalscenarios.missingshock.MissingShockJobMain_1522810414013',
        appLocation: 'uklpadsab126a.uk.standardchartered.com',
        appVersion: '0.0.34548_3',
        appInstance: 'application_1521942550407_1001',
        meta: {
            className:
                'com.scb.sabre.store.job.feed.globalscenarios.missingshock.MissingShockJobMain_1522810414013',
            targetFile:
                'hdfs:///sabrestore/dev/datasets/appsets/marketrisk/stress/global-missingshocks/Oil_Price_Spike/date=2018-03-23/version=1/appset.parquet',
        },
        _userId: 'SMR_DEV_RO',
        ttl: 31536000,
        sources: [
            {
                id:
                    'hdfs:///sabrestore/dev/datasets/raw/fdsf/SABRE-36405/asOfDate=2018-03-23/run=overnight/batch=mrb_shocks_market_*/*/GlobalScenariosUnshockedNode.parquet',
            },
        ],
        _createdTime: '2018-04-04T15:09:46Z',
    },
    tables: [{ name: 'Error', sizeInBytes: 7020 }, { name: 'appset', sizeInBytes: 275613 }],
    transactions: [],
};

export const activePivotFileList = [
    {
        dataSetId: 'appsets/marketrisk/active_pivot/exception_tickets/date=2018-01-25/version=1',
        modificationTime: '2018-03-05T17:23:18Z',
    },
    {
        dataSetId: 'appsets/marketrisk/active_pivot/exception_tickets/date=2018-03-13/version=1',
        modificationTime: '2018-03-14T00:21:31Z',
    },
    {
        dataSetId: 'appsets/marketrisk/active_pivot/exception_tickets/date=2018-03-15/version=1',
        modificationTime: '2018-03-16T00:23:12Z',
    },
    {
        dataSetId: 'appsets/marketrisk/active_pivot/exception_tickets/date=2018-03-16/version=1',
        modificationTime: '2018-05-15T12:11:28Z',
    },
    {
        dataSetId: 'appsets/marketrisk/active_pivot/exception_tickets/date=2018-03-20/version=1',
        modificationTime: '2018-04-05T10:06:19Z',
    },
    {
        dataSetId: 'appsets/marketrisk/active_pivot/sensitivities/date=2018-03-20/version=1',
        modificationTime: '2018-04-05T10:04:11Z',
    },
    {
        dataSetId: 'appsets/marketrisk/active_pivot/sensitivities/date=2018-03-23/version=1',
        modificationTime: '2018-04-04T12:16:16Z',
    },
    {
        dataSetId: 'appsets/marketrisk/active_pivot/sensitivities/date=2018-04-05/version=1',
        modificationTime: '2018-04-09T12:25:59Z',
    },
];
