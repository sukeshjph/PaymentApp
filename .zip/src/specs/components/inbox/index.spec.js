import React from 'react';
import { shallow, mount } from 'enzyme';
import toJson from 'enzyme-to-json';
import { Inbox } from '../../../components/inbox/index';
import ErrorMessage from '../../../components/shared/errorMessage';
import mockInboxResponse from '../../mocks/mockInboxResponse';
import mockBatchesResponse from '../../mocks/mockBatchListResponse';
import LoadingData from '../../../components/shared/loadingData';

jest.mock('../../../common/config');
jest.mock('../../../helpers/authentication');
jest.mock('../../../helpers/dateTime');
jest.mock('../../../components/shared/userPopover');

describe('Inbox component', () => {
    const initialProps = {
        actions: {
            signOut: () => undefined,
            fetchInbox: () => undefined,
            fetchBatches: () => undefined,
            fetchDiff: () => undefined,
            approveScenario: () => undefined,
            declineScenario: () => undefined,
        },
        batchModel: {
            batches: mockBatchesResponse,
        },
        inboxModel: {
            inbox: mockInboxResponse,
            inboxError: '',
            isSaving: false,
        },
        diffModel: {
            fetchDiffError: '',
            diff: {},
            isFetchingDiff: false,
        },
        user: {
            userDisplayName: '',
            entitlements: '',
            userName: 'Steve',
        },
    };
    let wrapper;
    const setup = () => {
        wrapper = shallow(<Inbox { ...initialProps } />);
    };

    beforeEach(() => {
        setup();
    });

    describe('rendering', () => {
        it('should render with initial props and state', () => {
            expect(toJson(wrapper)).toMatchSnapshot();
        });
    });

    describe('component mounting', () => {
        it('fetches inbox data', () => {
            const spy = jest.spyOn(initialProps.actions, 'fetchInbox');
            mount(<Inbox { ...initialProps } />);
            expect(spy).toHaveBeenCalled();
        });
    });

    describe('loading', () => {
        it('displays a spinner', () => {
            const newProps = {
                ...initialProps,
                inboxModel: {
                    ...initialProps.inboxModel,
                    isFetchingInbox: true,
                },
            };
            wrapper.setProps(newProps);
            expect(
                wrapper
                    .find(LoadingData)
                    .shallow()
                    .childAt(0),
            ).toHaveLength(1);
        });
    });

    describe('loading error', () => {
        it('displays a message to the user', () => {
            const newProps = {
                ...initialProps,
                inboxModel: {
                    ...initialProps.inboxModel,
                    inboxError: 'Test error',
                },
            };
            wrapper.setProps(newProps);
            expect(wrapper.find(ErrorMessage).props().message).toBe('Test error');
        });
    });

    describe('inbox is empty', () => {
        it('displays a message to the user', () => {
            const newProps = {
                ...initialProps,
                inboxModel: {
                    ...initialProps.inboxModel,
                    isFetchingInbox: false,
                    inbox: [],
                },
            };
            wrapper.setProps(newProps);
            expect(wrapper.find(ErrorMessage).props().message).toBe('There are no scenario files awaiting approval.');
        });
    });

    describe('receiving props', () => {
        it('adds user RO / RW permissions to state', () => {
            wrapper.setState({ 'userCanEdit': false });
            wrapper.setProps({ model: { inbox: [] }, user: {}});
            expect(wrapper.state('userCanEdit')).toBe(true);
        });

        it('adds the inbox data to state', () => {
            const newInbox = [{}, {}];
            wrapper.setProps({
                inboxModel: {
                    ...initialProps.inboxModel,
                    inbox: newInbox,
                },
            });
            expect(wrapper.state('inbox')).toEqual(newInbox);
        });
    });

    describe('closing the form dialog', () => {
        let refreshInboxSpy;
        beforeEach(() => {
            refreshInboxSpy = jest.spyOn(initialProps.actions, 'fetchInbox');
            setup();
            refreshInboxSpy.mockRestore(); // Spy is called when component mounts, need to reset it.
            wrapper.setState({
                userAction: 'approve',
                openFormDialog: true,
            });
        });
        describe('inbox needs refreshed', () => {
            beforeEach(() => {
                wrapper.instance().closeFormDialog(true);
            });
            it.skip('calls the fetch inbox action', () => {
                expect(refreshInboxSpy).toHaveBeenCalled();
            });
            it('closes the dialog', () => {
                expect(wrapper.state('openFormDialog')).toBe(false);
            });
            it('resets state.userAction', () => {
                expect(wrapper.state('userAction')).toBe('');
            });
        });
        describe('inbox does not need refreshed', () => {
            beforeEach(() => {
                wrapper.instance().closeFormDialog();
            });
            it('does not call the fetch inbox action', () => {
                expect(refreshInboxSpy).not.toHaveBeenCalled();
            });
            it('closes the dialog', () => {
                expect(wrapper.state('openFormDialog')).toBe(false);
            });
            it('resets state.userAction', () => {
                expect(wrapper.state('userAction')).toBe('');
            });
        });
    });


    describe('selecting a scenario', () => {
        let approveButton;
        let declineButton;
        let compareButton;
        beforeEach(() => {
            wrapper.setProps({
                inboxModel: {
                    ...initialProps.inboxModel,
                    inbox: mockInboxResponse,
                },
                user: {
                    userName: '11111',
                },
            });
            wrapper.find('.stress-table--row').at(0).simulate('click');
            approveButton = wrapper.find('#stress-inbox--approve-button').at(0);
            declineButton = wrapper.find('#stress-inbox--decline-button').at(0);
            compareButton = wrapper.find('#stress-inbox--compare-button').at(0);
        });
        it('adds the scenario to state', () => {
            expect(wrapper.state('selectedScenario')).toEqual(mockInboxResponse[0]);
        });

        it('enables the compare button', () => {
            expect(compareButton.props().disabled).toBe(false);
        });

        describe('if user has created it', () => {
            beforeEach(() => {
                wrapper.setProps({
                    user: {
                        userName: '12345',
                    },
                });
            });
            it('disables the approve button', () => {
                expect(approveButton.props().disabled).toBe(false);
            });
            it('disables the decline button', () => {
                expect(declineButton.props().disabled).toBe(false);
            });
        });

        describe('no scenario file exists (currentActiveFileVersion is undefined)', () => {
            beforeEach(() => {
                wrapper.find('.stress-table--row').at(1).simulate('click');
                approveButton = wrapper.find('#stress-inbox--approve-button').at(0);
                declineButton = wrapper.find('#stress-inbox--decline-button').at(0);
                compareButton = wrapper.find('#stress-inbox--compare-button').at(0);
            });
            it('disables the compare button', () => {
                expect(compareButton.props().disabled).toBe(true);
            });
        });

        describe('clicking approve', () => {
            beforeEach(() => {
                approveButton = approveButton.dive().find('button').at(0);
                approveButton.simulate('click');
            });
            it('opens the approve dialog', () => {
                expect(wrapper.state('openFormDialog')).toBe(true);
                expect(wrapper.state('userAction')).toBe('approve');
            });
            it('applies correct props to inboxFormDialog', () => {
                // TODO
            });
        });

        describe('clicking decline', () => {
            beforeEach(() => {
                declineButton = declineButton.dive().find('button').at(0);
                declineButton.simulate('click');
            });
            it('opens the decline dialog', () => {
                expect(wrapper.state('openFormDialog')).toBe(true);
                expect(wrapper.state('userAction')).toBe('decline');
            });
            it('applies correct props to inboxFormDialog', () => {
                // TODO
            });
        });

        describe('saving', () => {
            const comments = 'comments';
            const committee = 'committee';

            describe('approvals', () => {
                const spy = jest.spyOn(initialProps.actions, 'approveScenario');
                setup();
                wrapper.setState({
                    selectedScenario: mockInboxResponse[0],
                    userAction: 'approve',
                });
                wrapper.instance().saveHandler(comments, committee);
                expect(spy).toHaveBeenCalledWith(mockInboxResponse[0], comments, committee);
            });

            describe('declines', () => {
                const spy = jest.spyOn(initialProps.actions, 'declineScenario');
                setup();
                wrapper.setState({
                    selectedScenario: mockInboxResponse[0],
                    userAction: 'decline',
                });
                wrapper.instance().saveHandler(comments, committee);
                expect(spy).toHaveBeenCalledWith(mockInboxResponse[0], comments, committee);
            });
        });
    });
});