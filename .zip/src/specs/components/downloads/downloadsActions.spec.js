import * as actions from '../../../components/downloads/downloadsActions';
import { downloadActionTypes } from '../../../components/downloads/downloadsConstants';

jest.mock('../../../helpers/authentication');

describe('Download Actions', () => {
    it('passes root and regexFilter params with the FETCH_FILE_LIST action', () => {
        const action = actions.fetchFileList('root', 'regexFilter');
        expect(action.type)
            .toEqual(downloadActionTypes.FETCH_FILE_LIST);
        expect(action.payload.root).toBe('root');
        expect(action.payload.regexFilter).toBe('regexFilter');
    });

    it('passes datasetId param with the FETCH_FILE_DETAILS action', () => {
        const action = actions.fetchFileDetails('datasetId');
        expect(action.type)
            .toEqual(downloadActionTypes.FETCH_FILE_DETAILS);
        expect(action.payload.datasetId).toBe('datasetId');
    });

    it('passes datasetId and blobName params with the FETCH_BLOB action', () => {
        const action = actions.fetchBlobFile('datasetId', 'blobName');
        expect(action.type)
            .toEqual(downloadActionTypes.FETCH_BLOB);
        expect(action.payload.datasetId).toBe('datasetId');
        expect(action.payload.blobName).toBe('blobName');
    });

    it('dispatches a FETCH_BLOB_RESET action', () => {
        const action = actions.fetchBlobReset();
        expect(action.type)
            .toEqual(downloadActionTypes.FETCH_BLOB_RESET);
    });
});

