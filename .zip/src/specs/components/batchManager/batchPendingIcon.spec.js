import React from 'react';
import { shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import PendingIcon from '../../../components/batchManager/batchPendingIcon';

describe('Pending icon', () => {

    let wrapper;

    beforeEach(() => {
        wrapper = shallow(<PendingIcon pending />);
    });

    it('renders a link which points to the inbox', () => {
        expect(toJson(wrapper)).toMatchSnapshot();
    });

    it('renders nothing if pending prop is false', () => {
        wrapper = shallow(<PendingIcon />);
        expect(wrapper.find('span').children()).toHaveLength(0);
    });

});