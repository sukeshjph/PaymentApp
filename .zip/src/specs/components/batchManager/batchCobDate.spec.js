import React from 'react';
import { shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import moment from 'moment';
import BatchCobDate from '../../../components/batchManager/batchCoBDate';

describe('BatchCobDate component', () => {

    let wrapper;
    const initialProps = {
        batchName: 'Monday',
        batchCoBDate: '2018-01-01',
        editable: true,
        hasCoBDateChanged: false,
        handleCoBDateChange: jest.fn(),
        handleUndoCoBDateChange: jest.fn(),
    };

    beforeEach(() => {
        Date.now = jest.fn(() => 1537270248465); // 18th September 2018
        wrapper = shallow(<BatchCobDate { ...initialProps } />);
    });

    describe('initialisation', () => {
        it('should render with initial props and state', () => {
            expect(toJson(wrapper)).toMatchSnapshot();
        });
        it('sets state.batchCoBDate', () => {
            expect(wrapper.state('batchCoBDate')).toBe(initialProps.batchCoBDate);
        });
        it('renders a DatePicker', () => {
            expect(wrapper.find('DatePicker')).toHaveLength(1);
        });
        it('renders a heading', () => {
            expect(wrapper.find('.stress-batch__dashboard__item__title').at(0).text())
                .toBe(`Optional CoB date override for ${ initialProps.batchName } batch`);
        });
    });

    describe('read only version', () => {
        it('does not render a DatePicker', () => {
            const newProps = {
                ...initialProps,
                editable: false,
            };
            wrapper = shallow(<BatchCobDate { ...newProps } />);
            expect(wrapper.find('DatePicker')).toHaveLength(0);
        });
        it('renders a different heading', () => {
            const newProps = {
                ...initialProps,
                editable: false,
            };
            wrapper = shallow(<BatchCobDate { ...newProps } />);
            expect(wrapper.find('.stress-batch__cob-date__title').at(0).text())
                .toBe(`CoB date for ${ initialProps.batchName } batch: ${ initialProps.batchCoBDate }`);
        });
    });

    describe('changing batchCoBDate prop', () => {
        it('updates state.batchCoBDate', () => {
            const updatedDate = '2018-01-02';
            wrapper.setProps({ batchCoBDate: updatedDate });
            wrapper.update();
            expect(wrapper.state('batchCoBDate')).toBe(updatedDate);
        });
    });

    describe('changing the datePicker date', () => {
        it('calls the handleCoBDateChange prop', () => {
            wrapper.instance().handleCoBDateChange(moment());
            expect(initialProps.handleCoBDateChange).toHaveBeenCalledWith('2018-09-18');
        });
    });

    describe('the clear button', () => {
        it('is disabled if no date has been selected', () => {
            const newProps = {
                ...initialProps,
                batchCoBDate: null,
            };
            wrapper = shallow(<BatchCobDate { ...newProps } />);
            expect(wrapper.find('.stress-batch__cob-date__clear').at(0).prop('disabled')).toBe(true);
        });
        it('is not disabled if a date has been selected', () => {
            expect(wrapper.find('.stress-batch__cob-date__clear').at(0).prop('disabled')).toBe(false);
        });
        it('calls the handleCoBDateChange prop when clicked', () => {
            const button = wrapper.find('.stress-batch__cob-date__clear').at(0);
            button.simulate('click');
            expect(initialProps.handleCoBDateChange).toHaveBeenCalledWith(null);
        });
    });

    describe('the undo button', () => {
        it('is not present if the date hasn\'t changed', () => {
            expect(wrapper.find('.stress-batch__cob-date__undo')).toHaveLength(0);
        });
        it('is present if the date has changed', () => {
            const newProps = {
                ...initialProps,
                hasCoBDateChanged: true,
            };
            wrapper = shallow(<BatchCobDate { ...newProps } />);
            expect(wrapper.find('.stress-batch__cob-date__undo')).toHaveLength(1);
        });
        it('calls the handleUndoCoBDateChange prop when clicked', () => {
            const newProps = {
                ...initialProps,
                hasCoBDateChanged: true,
            };
            wrapper = shallow(<BatchCobDate { ...newProps } />);
            const button = wrapper.find('.stress-batch__cob-date__undo').at(0);
            button.simulate('click');
            expect(initialProps.handleUndoCoBDateChange).toHaveBeenCalled();
        });
    });
});