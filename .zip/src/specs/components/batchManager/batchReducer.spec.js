import orderBy from 'lodash.orderby';
import {
    batchActionTypes,
    BATCH_SORT_ORDER,
} from '../../../components/batchManager/batchManagerConstants';
import reducer from '../../../components/batchManager/batchManagerReducer';
import mockBatchListResponse from '../../mocks/mockBatchListResponse';
import mockBatchAuditListResponse from '../../mocks/mockBatchAuditListResponse';
import mockScenarioListResponse from '../../mocks/mockScenarioListResponse';

const initialState = {
    batches: [],
    scenarios: [],
    batchAudits: [],
    pctNodeTree: {},
    isSavingBatch: false,
    isFetchingBatches: false,
    isFetchingScenarios: false,
    isFetchingPctNodes: false,
    pctNodeError: '',
};

const error = { message: 'nasty big error booo' };
const sortedScenarioIds = ['1', '7', '3', '9', '5', '13', '11'];

describe('Batch reducer', () => {
    it('returns the initial state', () => {
        expect(reducer(undefined, {})).toEqual(initialState);
    });

    describe('FETCH_BATCHES reducer', () => {
        it('sets loading flags to true when loading the list', () => {
            const action = {
                type: batchActionTypes.FETCH_BATCHES,
            };
            const outcome = reducer(initialState, action);
            expect(outcome.isFetchingBatches).toEqual(true);
        });
    });

    describe('FETCH_BATCHES_COMPLETE reducer', () => {
        const action = {
            type: batchActionTypes.FETCH_BATCHES_COMPLETE,
            payload: {
                batches: mockBatchListResponse,
                scenarios: mockScenarioListResponse,
                batchAudits: mockBatchAuditListResponse,
                pendingScenarios: [{ ukId: '5' }, { ukId: '13' }],
            },
        };
        const state = {
            isFetchingScenarios: true,
            isFetchingBatches: true,
        };
        let outcome;
        beforeEach(() => {
            outcome = reducer(state, action);
        });
        it('sets loading flags to false', () => {
            expect(outcome.isFetchingBatches).toEqual(false);
        });
        it('sorts the batches by day of the week', () => {
            const days = outcome.batches.map(batch => batch.name);
            expect(days).toEqual(BATCH_SORT_ORDER);
        });
    });

    describe('FETCH_BATCHES_ERROR reducer', () => {
        const action = {
            type: batchActionTypes.FETCH_BATCHES_ERROR,
            payload: { error },
        };
        const state = {
            isFetchingBatches: true,
        };
        it('sets loading flags to false', () => {
            const outcome = reducer(state, action);
            expect(outcome.isFetchingBatches).toEqual(false);
        });
        it('returns the error', () => {
            const outcome = reducer(state, action);
            expect(outcome.error).toEqual(error);
        });
    });

    describe('FETCH_BATCHES_AND_SCENARIOS reducer', () => {
        it('sets loading flags to true when loading the list', () => {
            const action = {
                type: batchActionTypes.FETCH_BATCHES_AND_SCENARIOS,
            };
            const outcome = reducer(initialState, action);
            expect(outcome.isFetchingBatches).toEqual(true);
            expect(outcome.isFetchingScenarios).toEqual(true);
        });
    });

    describe('FETCH_BATCHES_AND_SCENARIOS_COMPLETE reducer', () => {
        const action = {
            type: batchActionTypes.FETCH_BATCHES_AND_SCENARIOS_COMPLETE,
            payload: {
                batches: mockBatchListResponse,
                scenarios: mockScenarioListResponse,
                batchAudits: mockBatchAuditListResponse,
                pendingScenarios: [{ ukId: '5' }, { ukId: '13' }],
            },
        };
        const state = {
            isFetchingScenarios: true,
            isFetchingBatches: true,
        };
        let outcome;
        beforeEach(() => {
            outcome = reducer(state, action);
        });
        it('sets loading flags to false', () => {
            expect(outcome.isFetchingBatches).toEqual(false);
            expect(outcome.isFetchingScenarios).toEqual(false);
        });
        it('sorts the batches by day of the week', () => {
            const days = outcome.batches.map(batch => batch.name);
            expect(days).toEqual(BATCH_SORT_ORDER);
        });
        it('sorts the batchAudits by descending validFrom date', () => {
            const sortedBatchAudits = orderBy(mockBatchAuditListResponse, ['validFrom'], 'desc');
            expect(outcome.batchAudits).toEqual(sortedBatchAudits);
        });
        it.skip('sorts the scenarios alphabetically by name', () => {
            const scenarioIds = outcome.batches.map(batch => batch.id);
            expect(scenarioIds).toEqual(sortedScenarioIds);
        });
        it('adds pending:true to scenarios that have a pending item in the inbox', () => {
            expect(outcome.scenarios.find(({ ukId }) => ukId === '5').pending).toBe(true);
            expect(outcome.scenarios.find(({ ukId }) => ukId === '13').pending).toBe(true);
        });
    });

    describe('FETCH_BATCHES_AND_SCENARIOS_ERROR reducer', () => {
        const action = {
            type: batchActionTypes.FETCH_BATCHES_AND_SCENARIOS_ERROR,
            payload: { error },
        };
        const state = {
            isFetchingScenarios: true,
            isFetchingBatches: true,
        };
        it('sets loading flags to false', () => {
            const outcome = reducer(state, action);
            expect(outcome.isFetchingBatches).toEqual(false);
            expect(outcome.isFetchingScenarios).toEqual(false);
        });
        it('returns the error', () => {
            const outcome = reducer(state, action);
            expect(outcome.error).toEqual(error);
        });
    });

    describe('SAVE_BATCH reducer', () => {
        it('sets loading flags to true when saving the batch', () => {
            const action = {
                type: batchActionTypes.SAVE_BATCH,
                payload: {
                    batch: {},
                },
            };
            expect(reducer(initialState, action).isSavingBatch).toEqual(true);
        });
    });

    describe('SAVE_BATCH_COMPLETE reducer', () => {
        const action = {
            type: batchActionTypes.SAVE_BATCH_COMPLETE,
            payload: {
                batches: mockBatchListResponse,
                batchAudits: mockBatchAuditListResponse,
            },
        };
        const state = {
            isSavingBatch: true,
        };
        let outcome;
        beforeEach(() => {
            outcome = reducer(state, action);
        });
        it('sets loading flags to false when batches have loaded', () => {
            expect(outcome.isSavingBatch).toEqual(false);
        });
        it('sorts the batches by day of the week', () => {
            const days = outcome.batches.map(batch => batch.name);
            expect(days).toEqual(BATCH_SORT_ORDER);
        });
        it('sorts the batchAudits by descending validFrom date', () => {
            const sortedBatchAudits = orderBy(mockBatchAuditListResponse, ['validFrom'], 'desc');
            expect(outcome.batchAudits).toEqual(sortedBatchAudits);
        });
    });

    describe('SAVE_BATCH_ERROR reducer', () => {
        const action = {
            type: batchActionTypes.SAVE_BATCH_ERROR,
            payload: { error },
        };
        const state = {
            isSavingBatch: true,
        };
        it('sets loading flags to false', () => {
            const outcome = reducer(state, action);
            expect(outcome.isSavingBatch).toEqual(false);
        });
        it('returns the error', () => {
            const outcome = reducer(state, action);
            expect(outcome.error).toEqual(error);
        });
    });
});
