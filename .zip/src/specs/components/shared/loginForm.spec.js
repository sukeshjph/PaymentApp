import React from 'react';
import { shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import ErrorMessage from '../../../components/shared/errorMessage';
import LoginForm from '../../../components/shared/loginForm';
import LoadingButton from '../../../components/shared/loadingButton';
import { authenticationCredentials } from '../../../helpers/authentication';

jest.mock('../../../helpers/authentication', () => ({
    authenticationCredentials: jest.fn(),
}));

describe('Login Form', () => {
    let wrapper;
    let authMock;

    const initialProps = {
        signIn: () => undefined,
        failedAuthentication: false,
        isSigningIn: false,
    };
    const setup = newProps => {
        const props = newProps || initialProps;
        authenticationCredentials.mockImplementation(authMock);
        wrapper = shallow(<LoginForm { ...props } />);
    };

    beforeEach(() => {
        authMock = () => ({ entitlements: 'RW' });
    });

    it('renders a form', () => {
        setup();
        expect(toJson(wrapper)).toMatchSnapshot();        
    });

    describe('username field', () => {
        it('displays an error if invalid', () => {
            setup();
            wrapper.find('#stress__login__user').simulate('change', { target: { value: ''}});
            expect(wrapper.find('.stress__login__user__error').at(0).children().text()).toContain('Bank ID is required');
        });
    });

    describe('password field', () => {
        it('displays an error if invalid', () => {
            setup();
            wrapper.find('#stress__login__password').simulate('change', { target: { value: ''}});
            expect(wrapper.find('.stress__login__password__error').at(0).children().text()).toContain('Password is required');
        });
    });

    describe('failed authentication', () => {
        it('displays an error if user is not authorised', () => {
            authMock = () => ({ entitlements: 'UNAUTHORISED' });
            setup();
            expect(wrapper.find(ErrorMessage).at(0).props().message).toBe('You are not authorised to use Stress Testing');
        });
        it('displays an error if credentials are not recognised', () => {
            setup({
                ...initialProps,
                failedAuthentication: true,
            });
            expect(wrapper.find(ErrorMessage).at(0).props().message).toBe('Bank ID or password not recognised');
        });
    });

    describe('action button', () => {
        it('says "log in" by default', () => {
            setup();
            expect(wrapper.find('.stress__login__button').at(0).text()).toBe('Log in');
        });
        it('disabled by default', () => {
            setup();
            expect(wrapper.find('.stress__login__button').at(0).props().disabled).toBe(true);
        });
        it('says "logging in" if logging in', () => {
            setup({
                ...initialProps,
                isSigningIn: true,
            });
            expect(wrapper.find(LoadingButton).at(0).props().text).toBe('Logging in');
        });
        it('is disabled if form is invalid', () => {
            setup();
            expect(wrapper.find('.stress__login__button').at(0).props().disabled).toBe(true);
        });
        it('is enabled if form is valid', () => {
            setup();
            wrapper.setState({
                userId: 'valid',
                password: 'valid',
            });
            expect(wrapper.find('.stress__login__button').at(0).props().disabled).toBe(false);
        });
    });

    describe('clicking the log in button', () => {
        it('calls props.signIn with form values', () => {
            jest.spyOn(initialProps, 'signIn');
            setup();
            wrapper.setState({
                userId: 'valid',
                password: 'valid',
            });
            wrapper.find('.stress__login__button').at(0).simulate('click');
            expect(initialProps.signIn).toHaveBeenCalledWith('valid', 'valid');
        });
    });
});