import { shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import BatchListItemCell from '../../../components/batchAudit/batchListItemCell';

describe('BatchListItemCell component', () => {   
    describe('Should render withy  html list', () => {
        it('With csv list', () => {
            const list = 'Middle_East_War (v.1), Bond_Armageddon (v.1)';
            const wrapper = shallow(BatchListItemCell(list));
            expect(toJson(wrapper)).toMatchSnapshot();
        });
        it('With empty list', () => {
            const list = '';
            expect(BatchListItemCell(list)).toBeFalsy();           
        });
    })
});