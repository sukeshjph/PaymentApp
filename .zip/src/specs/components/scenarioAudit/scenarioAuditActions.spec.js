import moment from 'moment';
import * as actions from '../../../components/scenarioAudit/scenarioAuditActions';
import { scenarioAuditActionTypes } from '../../../components/scenarioAudit/scenarioAuditConstants';

jest.mock('../../../helpers/authentication');

describe('"fetchScenarioAudits" action', () => {
    it('dispatches a FETCH_SCENARIO_AUDITS action', () => {
        expect(actions.fetchScenarioAudits().type)
            .toEqual(scenarioAuditActionTypes.FETCH_SCENARIO_AUDITS);
    });
    it('sends validFromDate and validToDate params', () => {
        expect(actions.fetchScenarioAudits(moment('01/01/2018', 'DD/MM/YYYY'), moment('01/01/2019', 'DD/MM/YYYY')).payload)
            .toEqual({ validFromDate: '2018-01-01 00:00:00.000', validToDate: '2019-01-01 23:59:59.999' });
    });
    it('sets validFromDate to null if no param is passed', () => {
        Date.now = jest.fn(() => 1528105933097); // 4th June 2018
        expect(actions.fetchScenarioAudits().payload.validFromDate)
            .toBe(null);
    });
    it('sets validToDate to null if no param is passed', () => {
        Date.now = jest.fn(() => 1528105933097); // 4th June 2018
        expect(actions.fetchScenarioAudits().payload.validToDate)
            .toBe(null);
    });
});