import _ from 'lodash';
import { scenarioActionTypes } from '../../../components/scenarioManager/scenarioConstants';
import reducer from '../../../components/scenarioManager/scenarioReducer';
import mockScenarioListResponse from '../../mocks/mockScenarioListResponse';
import mockScenarioResponse from '../../mocks/mockScenarioResponse';

jest.mock('js-file-download');

const initialState = {
    scenarios: [],
    approvedScenarios: [],
    pendingScenarios: [],
    doesScenarioExist: false,
    isFetchingScenario: false,
    isFetchingScenarios: false,
    isFetchingScenarioDetails: false,
    isSavingScenario: false,
    isDeletingScenario: false,
    isCompilingScenario: false,
    isScenarioCompiled: false,
    compilationResult: { result: '', message: '' },
    hasDeletedScenario: false,
    scenarioError: '',
};

const error = { message: 'nasty big error booo' };
const sortedScenarioIds = [ '1', '7', '3', '9', '5', '13', '11' ];

describe('Scenario reducer', () => {
    it('returns the initial state', () => {
        expect(reducer(undefined, {})).toEqual(initialState);
    });


    describe('FETCH_SCENARIOS reducer', () => {
        it('sets loading flags to true', () => {
            const action = {
                type: scenarioActionTypes.FETCH_SCENARIOS,
            };
            const outcome = reducer(initialState, action);
            expect(outcome.isFetchingScenarios).toEqual(true);
        });
        it('resets any error messages', () => {
            const state = {
                ...initialState,
                error,
            };
            const action = {
                type: scenarioActionTypes.FETCH_SCENARIOS,
            };
            const outcome = reducer(state, action);
            expect(outcome.error).toEqual(null);
        });
    });


    describe('FETCH_SCENARIOS_COMPLETE reducer', () => {
        const action = {
            type: scenarioActionTypes.FETCH_SCENARIOS_COMPLETE,
            payload: {
                scenarios: mockScenarioListResponse,
                pendingScenarios: [{ ukId: '5' }, { ukId: '13' }],
            },
        };
        const state = {
            isFetchingScenarios: true,
        };
        let outcome;
        beforeEach(() => {
            outcome = reducer(state, action);
        });
        it('sets loading flags to false', () => {
            expect(outcome.isFetchingScenarios).toEqual(false);
        });
        it('sorts the scenarios alphabetically by name', () => {
            const scenarioIds = _.map(outcome.scenarios, 'id');
            expect(scenarioIds).toEqual(sortedScenarioIds);
        });
        it('adds pending:true to scenarios that have a pending item in the inbox', () => {
            expect(_.find(outcome.scenarios, { ukId: '5'}).pending).toBe(true);
            expect(_.find(outcome.scenarios, { ukId: '13'}).pending).toBe(true);
        });
        it('returns pending scenarios', () => {
            expect(outcome.pendingScenarios).toEqual(action.payload.pendingScenarios);
        });
    });


    describe('FETCH_SCENARIOS_ERROR reducer', () => {
        const action = {
            type: scenarioActionTypes.FETCH_SCENARIOS_ERROR,
            payload: { error },
        };
        const state = {
            isFetchingScenarios: true,
        };
        it('sets loading flags to false', () => {
            const outcome = reducer(state, action);
            expect(outcome.isFetchingScenarios).toEqual(false);
        });
        it('returns the error', () => {
            const outcome = reducer(state, action);
            expect(outcome.error).toEqual(error);
        })
    });


    describe('CREATE_SCENARIO and UPDATE_SCENARIO reducers', () => {
        it('sets loading flags to true when creating a scenario', () => {
            const types = [
                scenarioActionTypes.CREATE_SCENARIO,
                scenarioActionTypes.UPDATE_SCENARIO,
            ];
            _.forEach(types, (type) => {
                const outcome = reducer(initialState, {
                    type,
                    payload: {
                        scenario: {},
                    },
                });
                expect(outcome.isSavingScenario).toEqual(true);
            });
        });
    });


    describe('CREATE_SCENARIO_COMPLETE and UPDATE_SCENARIO_COMPLETE reducer', () => {
        const types = [
            scenarioActionTypes.CREATE_SCENARIO_COMPLETE,
            scenarioActionTypes.UPDATE_SCENARIO_COMPLETE,
        ];
        const state = {
            ...initialState,
            isSavingScenario: true,
        };
        let outcome;
        _.forEach(types, (type) => {
            beforeEach(() => {
                outcome = reducer(state, {
                    type,
                });
            });
            it('sets loading flags to false', () => {
                expect(outcome.isSavingScenario).toEqual(false);
            });
        });
    });


    describe('CREATE_SCENARIO_ERROR and UPDATE_SCENARIO_ERROR reducer', () => {
        const types = [
            scenarioActionTypes.CREATE_SCENARIO_ERROR,
            scenarioActionTypes.UPDATE_SCENARIO_ERROR,
        ];
        const state = {
            isSavingScenario: true,
            isFetchingScenarios: true,
        };
        let outcome;
        _.forEach(types, (type) => {
            beforeEach(() => {
                outcome = reducer(state, {
                    type,
                    payload: { scenarioError: error },
                });
            });
            it('sets loading flags to false', () => {
                expect(outcome.isSavingScenario).toEqual(false);
            });
            it('returns the error', () => {
                expect(outcome.scenarioError).toEqual(error);
            });
        });
    });

    describe('DELETE_SCENARIO reducer', () => {
        it('sets loading flags to true when deleting a scenario', () => {
            const action = {
                type: scenarioActionTypes.DELETE_SCENARIO,
                payload: {
                    scenario: '',
                },
            };
            const outcome = reducer(initialState, action);
            expect(outcome.isDeletingScenario).toEqual(true);
        });
    });

    describe('DELETE_SCENARIO_COMPLETE reducer', () => {
        it('sets loading flags to false', () => {
            const action = {
                type: scenarioActionTypes.DELETE_SCENARIO_COMPLETE,
            };
            const state = {
                isDeletingScenario: true,
            };
            const outcome = reducer(state, action);
            expect(outcome.isDeletingScenario).toEqual(false);
        });
    });

    describe('DELETE_SCENARIO_ERROR reducer', () => {
        const action = {
            type: scenarioActionTypes.DELETE_SCENARIO_ERROR,
            payload: { scenarioError: error },
        };
        const state = {
            isDeletingScenario: true,
        };
        it('sets loading flags to false when deleting a scenario throws an error', () => {
            const outcome = reducer(state, action);
            expect(outcome.isDeletingScenario).toEqual(false);
        });

        it('returns the error', () => {
            const outcome = reducer(state, action);
            expect(outcome.scenarioError).toEqual(error);
        });
    });

    describe('FETCH_SCENARIO reducer', () => {
        it('sets loading flags to true when fetching a scenario', () => {
            const action = {
                type: scenarioActionTypes.FETCH_SCENARIO,
                payload: {
                    scenario: '',
                },
            };
            const outcome = reducer(initialState, action);
            expect(outcome.isFetchingScenarioDetails).toEqual(true);
        });
    });

    describe('FETCH_SCENARIO_COMPLETE reducer', () => {
        const pending = {'activeFileVersion': 1, 'name': '13', 'type': 'Scenario', 'ukId': '13', 'validFrom': '2018-02-11 09:10:09.758', 'validTo': '9999-12-31 00:00:00.520'};
        const action = {
            type: scenarioActionTypes.FETCH_SCENARIO_COMPLETE,
            payload: {
                approved: mockScenarioResponse,
                pending: [pending],
            },
        };
        const state = { isFetchingScenarioDetails: true };
        let outcome;
        beforeEach(() => {
            outcome = reducer(state, action);
        });
        it('sets loading flags to false when scenario is returned', () => {
            expect(outcome.isFetchingScenarioDetails).toEqual(false);
        });
        it('de-dupes the file versions and sorts by descending activeFileVersion', () => {
            expect(_.map(outcome.approvedScenarios, 'activeFileVersion')).toEqual([ 3, 2, 1 ]);
        });
        it('returns the most recent pending scenario', () => {
            expect(outcome.pendingScenarios).toEqual([{ ...pending, pending: true }]);
        });
    });

    describe('FETCH_SCENARIO_ERROR reducer', () => {
        const action = {
            type: scenarioActionTypes.FETCH_SCENARIO_ERROR,
            payload: { error },
        };
        const state = {
            isFetchingScenarioDetails: true,
        };
        it('sets loading flags to false when fetching a scenario throws an error', () => {
            const outcome = reducer(state, action);
            expect(outcome.isFetchingScenarioDetails).toEqual(false);
        });

        it('returns the error', () => {
            const outcome = reducer(state, action);
            expect(outcome.error).toEqual(error);
        });
    });

    describe('SEARCH_SCENARIO reducer', () => {
        const action = {
            type: scenarioActionTypes.SEARCH_SCENARIO,
        };
        const state = {
            isFetchingScenario: false,
        };
        it('sets isFetchingScenario flags to true', () => {
            const outcome = reducer(state, action);
            expect(outcome.isFetchingScenario).toEqual(true);
        });
    });

    describe('SEARCH_SCENARIO_COMPLETE reducer', () => {
        const action = {
            type: scenarioActionTypes.SEARCH_SCENARIO_COMPLETE,
            payload: true,
        };
        const state = {
            isFetchingScenario: true,
            doesScenarioExist: false,
        };
        it('sets isFetchingScenario flags to false', () => {
            const outcome = reducer(state, action);
            expect(outcome.isFetchingScenario).toEqual(false);
        });
        it('confirms whether the scenario exists', () => {
            const outcome = reducer(state, action);
            expect(outcome.doesScenarioExist).toEqual(true);
        });
    });

    describe('SEARCH_SCENARIO_ERROR reducer', () => {
        const action = {
            type: scenarioActionTypes.SEARCH_SCENARIO_ERROR,
            payload: { error },
        };
        const state = {
            isFetchingScenario: true,
        };
        it('sets isFetchingScenario to false', () => {
            const outcome = reducer(state, action);
            expect(outcome.isFetchingScenario).toEqual(false);
        });

        it('returns the error', () => {
            const outcome = reducer(state, action);
            expect(outcome.error).toEqual(error);
        });
    });

    describe('DOWNLOAD_SCENARIO_FILE reducer', () => {
        const action = {
            type: scenarioActionTypes.DOWNLOAD_SCENARIO_FILE,
        };
        const state = {
            isDownloadingFile: false,
        };
        it('sets isDownloadingFile flags to true', () => {
            const outcome = reducer(state, action);
            expect(outcome.isDownloadingFile).toEqual(true);
        });
    });

    describe('DOWNLOAD_SCENARIO_FILE_COMPLETE reducer', () => {
        const action = {
            type: scenarioActionTypes.DOWNLOAD_SCENARIO_FILE_COMPLETE,
            payload: {
                blob: 'blob',
                filename: 'filename',
            },
        };
        const state = {
            isDownloadingFile: true,
        };
        it('sets isDownloadingFile flags to false', () => {
            const outcome = reducer(state, action);
            expect(outcome.isDownloadingFile).toEqual(false);
        });
        it('calls the fileDownload function', () => {
            // TODO: mock fileDownload and ensure it is called with correct params
            // jest.spyOn( );
            // reducer(state, action);
            // expect( ).toHaveBeenCalledWith('blob', 'filename');
        });
    });

    describe('DOWNLOAD_SCENARIO_FILE_ERROR reducer', () => {
        const action = {
            type: scenarioActionTypes.DOWNLOAD_SCENARIO_FILE_ERROR,
            payload: { error },
        };
        const state = {
            isDownloadingFile: true,
        };
        it('sets isDownloadingFile to false', () => {
            const outcome = reducer(state, action);
            expect(outcome.isDownloadingFile).toEqual(false);
        });

        it('returns the error', () => {
            const outcome = reducer(state, action);
            expect(outcome.error).toEqual(error);
        });
    });
});
