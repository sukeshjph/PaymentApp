import React from 'react';
import { shallow, mount } from 'enzyme';
import toJson from 'enzyme-to-json';
import _ from 'lodash';
import { ScenarioManager } from '../../../components/scenarioManager';
import mockScenarioResponse from '../../mocks/mockScenarioResponse';
import filterDataset from '../../../helpers/filterDataSet';
import ErrorMessage from '../../../components/shared/errorMessage';
import TooltipButton from '../../../components/shared/tooltipButton';
import LoadingData from '../../../components/shared/loadingData';

jest.mock('../../../common/config');
jest.mock('../../../helpers/filterDataSet');
jest.mock('../../../helpers/authentication');
jest.mock('../../../components/shared/userPopover');

describe('ScenarioManager component', () => {
    const initialProps = {
        actions: {
            fetchBatches: () => undefined,
            fetchScenarios: () => undefined,
            fetchScenarioDetails: () => undefined,
            compileScenarioFileCancel: () => undefined,
            updateScenario: () => undefined,
            createScenario: () => undefined,
            deleteScenario: () => undefined,
            signOut: () => undefined,
            downloadScenarioFile: () => undefined,
            fetchDiff: () => undefined,
        },
        scenarioModel: {
            scenarios: mockScenarioResponse,
            isFetchingScenarios: false,
            isDeletingScenario: false,
        },
        batchModel: {
            batches: [],
            isFetchingBatches: false,
        },
        diffModel: {
            isFetchingDiff: false,
            fetchDiffError: '',
            diff: {},
        },
        user: {
            userDisplayName: '',
            entitlements: '',
        },
    };
    let wrapper;

    const setup = () => {
        wrapper = shallow(<ScenarioManager {...initialProps} />);
    };

    it('renders with initial props and state', () => {
        setup();
        expect(toJson(wrapper)).toMatchSnapshot();
    });

    it('displays a loading spinner', () => {
        setup();
        expect(wrapper.find('.stress-loading')).toHaveLength(0);
        wrapper.setProps({
            ...initialProps,
            scenarioModel: {
                ...initialProps.scenarioModel,
                isFetchingScenarios: true,
            },
        });
        expect(
            wrapper
                .find(LoadingData)
                .shallow()
                .childAt(0),
        ).toHaveLength(1);
    });

    it('displays an error message', () => {
        setup();
        expect(wrapper.find('.stress__error')).toHaveLength(0);
        wrapper.setProps({
            ...initialProps,
            scenarioModel: {
                ...initialProps.scenarioModel,
                scenarioError: 'error',
                scenarios: [],
            },
        });
        expect(wrapper.find(ErrorMessage).props().message).toBe(
            'Sorry, an unexpected error has occurred.',
        );
    });

    describe('component mounting', () => {
        it('fetches batch and scenario data', () => {
            const fetchBatchesSpy = jest.spyOn(initialProps.actions, 'fetchBatches');
            const fetchScenariosSpy = jest.spyOn(initialProps.actions, 'fetchScenarios');
            mount(<ScenarioManager {...initialProps} />);
            expect(fetchBatchesSpy).toHaveBeenCalled();
            expect(fetchScenariosSpy).toHaveBeenCalled();
        });
    });

    describe('componentWillReceiveProps()', () => {
        it('determines user edit permissions', () => {
            setup();
            wrapper.setState({ userCanEdit: false });
            wrapper.setProps({ model: {}, user: {} });
            expect(wrapper.state('userCanEdit')).toBe(true);
        });

        it('re-applies any filters the user has set to incoming scenarios', () => {
            const spy = jest.spyOn(wrapper.instance(), 'applyCurrentFilters');
            const newProps = {
                ...initialProps,
                scenarioModel: {
                    ...initialProps.scenarioModel,
                    scenarios: [
                        ...initialProps.scenarioModel.scenarios,
                        {
                            type: 'Scenario',
                            ukId: '15',
                            validFrom: '2018-02-09 09:10:09.758',
                            validTo: '9999-12-31 00:00:00.520',
                            activeFileVersion: 1,
                        },
                    ],
                },
            };
            wrapper.setProps(newProps);
            expect(spy).toHaveBeenCalledWith(newProps.scenarioModel.scenarios);
        });
    });

    describe('action buttons', () => {
        const selectedScenarioUkId = '14';
        let addNewButton;
        let deleteButton;
        let editButton;
        let downloadButton;
        let versionsButton;

        const configureActionButtons = state => {
            setup();
            wrapper.setState(Object.assign({}, state, { selectedScenarioUkId }));
            addNewButton = wrapper.find(TooltipButton).find('.stress--scenario-actions--add');
            deleteButton = wrapper.find(TooltipButton).find('.stress--scenario-actions--delete');
            editButton = wrapper.find(TooltipButton).find('.stress--scenario-actions--edit');
            downloadButton = wrapper
                .find(TooltipButton)
                .find('.stress--scenario-actions--download');
            versionsButton = wrapper
                .find(TooltipButton)
                .find('.stress--scenario-actions--versions');
        };

        describe('Super User entitlements', () => {
            beforeEach(() => {
                configureActionButtons({ userIsSuperUser: true, userCanEdit: true });
            });
            it('renders NEW scenario button', () => {
                expect(addNewButton).toHaveLength(1);
            });
            it('renders DELETE scenario button', () => {
                expect(deleteButton).toHaveLength(1);
            });
            it('renders EDIT scenario button', () => {
                expect(editButton).toHaveLength(1);
            });
            it('renders FILE VERSIONS button', () => {
                expect(versionsButton).toHaveLength(1);
            });
            it('renders DOWNLOADS button', () => {
                expect(downloadButton).toHaveLength(1);
            });
        });

        describe('Read Only entitlements', () => {
            beforeEach(() => {
                configureActionButtons({ userCanEdit: false });
            });
            it('hides NEW scenario button', () => {
                expect(addNewButton).toHaveLength(0);
            });
            it('hides DELETE scenario button', () => {
                expect(deleteButton).toHaveLength(0);
            });
            it('hides EDIT scenario button', () => {
                expect(editButton).toHaveLength(0);
            });
            it('renders FILE VERSIONS button', () => {
                expect(versionsButton).toHaveLength(1);
            });
            it('renders DOWNLOADS button', () => {
                expect(downloadButton).toHaveLength(1);
            });
        });

        describe('Read Write entitlements', () => {
            beforeEach(() => {
                configureActionButtons({ userCanEdit: true });
            });
            it('hides NEW scenario button', () => {
                expect(addNewButton).toHaveLength(0);
            });
            it('hides DELETE scenario button', () => {
                expect(deleteButton).toHaveLength(0);
            });
            it('renders EDIT scenario button', () => {
                expect(editButton).toHaveLength(1);
            });
            it('renders FILE VERSIONS button', () => {
                expect(versionsButton).toHaveLength(1);
            });
            it('renders DOWNLOADS button', () => {
                expect(downloadButton).toHaveLength(1);
            });
        });
    });

    describe('Filtering the scenarios', () => {
        it('filters scenarios when filter text input changes', () => {
            setup();
            const filterText = 'test';
            const scenarios = [];
            wrapper.instance().handleFilterTextChange(filterText, scenarios);
            expect(wrapper.instance().state.filterText).toBe(filterText);
            expect(wrapper.instance().state.scenarios).toHaveLength(0);
        });

        it('applyCurrentFilters()', () => {
            setup();
            wrapper.instance().setState({ filterText: 'hh' });
            wrapper.instance().applyCurrentFilters(mockScenarioResponse);
            expect(filterDataset).toHaveBeenCalledWith('hh', mockScenarioResponse);
        });
    });

    describe('Selecting a scenario', () => {
        beforeEach(() => {
            setup();
            wrapper.instance().setSelectedScenario('1');
        });
        it('sets state.scenarioBeingEdited', () => {
            expect(wrapper.state('selectedScenarioUkId')).toBe('1');
        });
    });

    describe('Download button', () => {
        beforeEach(() => {
            setup();
            wrapper.instance().downloadScenarioHandler('4');
        });
        it('toggles state.openFileDownload', () => {
            expect(wrapper.state('openFileDownload')).toBe(true);
        });
        it('sets state.scenarioBeingEdited', () => {
            expect(wrapper.state('scenarioBeingDownloaded')).toEqual(
                _.filter(mockScenarioResponse, { ukId: '4' })[0],
            );
        });
    });

    describe('Edit button', () => {
        beforeEach(() => {
            setup();
            wrapper.instance().editScenarioHandler('2');
        });
        it('opens the edit modal', () => {
            expect(wrapper.state('openEditModal')).toBe(true);
        });
        it('sets state.scenarioBeingEdited', () => {
            expect(wrapper.state('scenarioBeingEdited')).toEqual(
                _.filter(mockScenarioResponse, { ukId: '2' })[0],
            );
        });
    });

    describe('Delete button', () => {
        beforeEach(() => {
            setup();
            wrapper.instance().openDeleteModalHandler('2');
        });
        it('opens the delete modal', () => {
            expect(wrapper.state('openDeleteModal')).toBe(true);
        });
        it('sets state.scenarioBeingDeleted', () => {
            expect(wrapper.state('scenarioBeingDeleted')).toEqual('2');
        });
    });

    describe('File Versions button', () => {
        beforeEach(() => {
            setup();
            wrapper.instance().editFileVersionHandler('3');
        });
        it('opens the file version modal', () => {
            expect(wrapper.state('openFileVersionModal')).toBe(true);
        });
        it('sets state.scenarioBeingEdited', () => {
            expect(wrapper.state('scenarioBeingEdited')).toEqual(
                _.filter(mockScenarioResponse, { ukId: '3' })[0],
            );
        });
    });

    describe('closing ScenarioAddEditDialog', () => {
        it('closeAddEditDialog closes the dialog', () => {
            setup();
            wrapper.setState({ openEditModal: true });
            wrapper.instance().closeAddEditDialog();
            expect(wrapper.state('openEditModal')).toBe(false);
        });
    });

    describe('closing ScenarioVersionsDialog', () => {
        beforeEach(() => {
            setup();
            wrapper.setState({
                openFileVersionModal: true,
                scenarioBeingEdited: { pending: true },
            });
        });

        it('closes the dialog when doneHandler is called', () => {
            wrapper.instance().closeVersionDialog();
            expect(wrapper.state('openFileVersionModal')).toBe(false);
        });
        it('closes the dialog when cancelhandler is called', () => {
            wrapper.instance().dialogHandler('openFileVersionModal');
            expect(wrapper.state('openFileVersionModal')).toBe(false);
        });
    });

    describe('closing ScenarioDownloadsDialog', () => {
        it('the cancelHandler closes the dialog', () => {
            setup();
            wrapper.setState({ openFileDownload: true });
            wrapper.instance().dialogHandler('openFileDownload');
            expect(wrapper.state('openFileDownload')).toBe(false);
        });
    });

    describe('closing DeleteDialog', () => {
        beforeEach(() => {
            setup();
            wrapper.setState({ openDeleteModal: true });
        });
        it('closes the dialog', () => {
            wrapper.instance().doneDeletingHandler();
            expect(wrapper.state('openDeleteModal')).toBe(false);
        });
        it('sets state.scenarioBeingDeleted to an empty string', () => {
            wrapper.instance().doneDeletingHandler();
            expect(wrapper.state('scenarioBeingDeleted')).toBe('');
        });
        it('fetches the scenarios', () => {
            const spy = jest.spyOn(initialProps.actions, 'fetchScenarios');
            setup();
            wrapper.setState({ openDeleteModal: true });
            wrapper.instance().doneDeletingHandler();
            expect(spy).toHaveBeenCalled();
        });
    });

    describe('scenario compilation', () => {
        const compileScenarioFileCancel = jest.fn();
        const newProps = {
            ...initialProps,
            actions: { ...initialProps.actions, compileScenarioFileCancel },
        };

        it('cancel compilation', () => {
            setup(newProps);
            wrapper.setProps({ ...newProps });
            wrapper.instance().cancelCompilationHandler();
            expect(compileScenarioFileCancel).toHaveBeenCalled();
        });
    });
});
