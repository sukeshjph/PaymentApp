import React from 'react';
import { shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import ScenarioDeleteDialog from '../../../components/scenarioManager/scenarioDeleteDialog';

jest.mock('../../../helpers/getAffectedBatches', () => () => 'Monday, Tuesday');

describe('Scenario Delete Dialog', () => {
    const initialProps = {
        cancelHandler: () => undefined,
        confirmHandler: () => undefined,
        doneHandler: () => undefined,
        data: {
            scenarioBeingDeleted: '123456',
            scenarios: [
                { ukId: '12345', name: '12345' },
                { ukId: '123456', name: '123456' },
                { ukId: '1234567', name: '1234567' },
            ],
        },
    };

    let wrapper;
    const setup = () => {
        wrapper = shallow(<ScenarioDeleteDialog { ...initialProps } />);
    };
    
    it('should render without error', () => {
        setup();
        expect(toJson(wrapper)).toMatchSnapshot();        
    });

    it('displays scenario name in the dialog title', () => {
        setup();
        expect(wrapper.find('#delete-scenario-dialog-title').dive().children().text()).toContain('Delete 123456?')
    });

    it('displays names of batches which will be affected by the delete action', () => {
        setup();
        expect(wrapper.find('.stress__delete-scenario-dialog__affected').at(0).text()).toContain('Monday, Tuesday');
    });

    describe('cancel button', () => {
        it('calls props.cancelHandler on click', () => {
            const spy = jest.spyOn(initialProps, 'cancelHandler');
            setup();
            wrapper.find('.stress__delete-dialog__cancel').at(0).simulate('click');
            expect(spy).toHaveBeenCalled();
        });
    });
});