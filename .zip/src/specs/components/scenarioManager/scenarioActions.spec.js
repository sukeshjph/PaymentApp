import * as scenarioActions from '../../../components/scenarioManager/scenarioActions';
import { scenarioActionTypes } from '../../../components/scenarioManager/scenarioConstants';

jest.mock('../../../helpers/authentication');

describe('fetchScenarios action', () => {
    it('dispatches a FETCH_SCENARIOS action', () => {
        expect(scenarioActions.fetchScenarios().type).toEqual(scenarioActionTypes.FETCH_SCENARIOS);
    });
});

describe('Scenario "fetchScenarioDetails" action', () => {
    it('dispatches a FETCH_SCENARIO action', () => {
        const ukId = '123456789';
        expect(scenarioActions.fetchScenarioDetails(ukId).type).toEqual(
            scenarioActionTypes.FETCH_SCENARIO,
        );
        expect(scenarioActions.fetchScenarioDetails(ukId).payload).toEqual({ ukId });
    });
});

describe('Scenario "createScenario" action', () => {
    it('dispatches a CREATE_SCENARIO action', () => {
        const sampleScenario = { ukId: '123456789' };
        expect(scenarioActions.createScenario(sampleScenario).type).toEqual(
            scenarioActionTypes.CREATE_SCENARIO,
        );
    });
    it('joins the tags array into a string', () => {
        const sampleScenario = { ukId: '123456789', tags: ['Global', 'Localised'] };
        expect(scenarioActions.createScenario(sampleScenario).payload).toEqual({
            scenario: {
                ...sampleScenario,
                tags: 'Global, Localised',
            },
        });
    });
    it('sets tags to null if none are present', () => {
        const sampleScenario = { ukId: '123456789' };
        expect(scenarioActions.createScenario(sampleScenario).payload).toEqual({
            scenario: {
                ...sampleScenario,
                tags: '',
            },
        });
    });
});

describe('Scenario "updateScenario" action', () => {
    it('dispatches a UPDATE_SCENARIO action', () => {
        const sampleScenario = { ukId: '123456789' };
        expect(scenarioActions.updateScenario(sampleScenario).type).toEqual(
            scenarioActionTypes.UPDATE_SCENARIO,
        );
    });
    it('joins the tags array into a string', () => {
        const sampleScenario = { ukId: '123456789', tags: ['Global', 'Localised'] };
        expect(scenarioActions.updateScenario(sampleScenario).payload).toEqual({
            scenario: {
                ...sampleScenario,
                tags: 'Global, Localised',
            },
        });
    });
    it('sets tags to null if none are present', () => {
        const sampleScenario = { ukId: '123456789' };
        expect(scenarioActions.updateScenario(sampleScenario).payload).toEqual({
            scenario: {
                ...sampleScenario,
                tags: '',
            },
        });
    });
});

describe('Scenario "downloadScenarioFile" action', () => {
    it('dispatches a DOWNLOAD_SCENARIO_FILE action', () => {
        expect(scenarioActions.downloadScenarioFile().type).toEqual(
            scenarioActionTypes.DOWNLOAD_SCENARIO_FILE,
        );
    });
});

describe('Scenario "deleteScenario" action', () => {
    it('dispatches a DELETE_SCENARIO action', () => {
        const ukId = '123456789';
        const comments = 'this is a comment';
        expect(scenarioActions.deleteScenario(ukId, comments).type).toEqual(
            scenarioActionTypes.DELETE_SCENARIO,
        );
        expect(scenarioActions.deleteScenario(ukId, comments).payload).toEqual({ ukId, comments });
    });
});
