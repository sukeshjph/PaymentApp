// import { combineReducers } from 'redux';
// import batchDetailsReducer from '../components/batchDetails/batchDetailsReducer';
// import batchSummaryReducer from '../components/batchSummary/batchSummaryReducer';
// import scenarioReducer from '../components/scenarioManager/scenarioReducer';
// import scenarioAuditReducer from '../components/scenarioAudit/scenarioAuditReducer';
// import batchAuditReducer from '../components/batchAudit/batchAuditReducer';
// import inboxReducer from '../components/inbox/inboxReducer';
// import downloadsReducer from '../components/downloads/downloadsReducer';
// import authReducer from './authReducer';
// import diffReducer from './diffReducer';
// import batchScheduleReducer from '../components/batchSchedule/batchScheduleReducer';
// import { AppState } from '../interfaces/globals';

// const rootReducer = combineReducers<AppState>({
//     BATCHES: batchSummaryReducer,
//     BATCH_DETAILS: batchDetailsReducer,
//     BATCH_AUDITS: batchAuditReducer,
//     BATCH_SCHEDULES: batchScheduleReducer,
//     DOWNLOADS: downloadsReducer,
//     INBOX: inboxReducer,
//     DIFF: diffReducer,
//     SCENARIOS: scenarioReducer,
//     SCENARIO_AUDITS: scenarioAuditReducer,
//     USER: authReducer,
// });

// export default rootReducer;
