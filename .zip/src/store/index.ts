import { createStore, applyMiddleware } from 'redux';
import logger from 'redux-logger';
import { createEpicMiddleware } from 'redux-observable';
import epics from '../epics';
import rootReducer from '../reducers';

export default function configureStore(initialState) {
    const epicMiddleware = createEpicMiddleware();
    const store = createStore(rootReducer, initialState, applyMiddleware(epicMiddleware, logger));
    epicMiddleware.run(epics);
    return store;
}
