import { ActionType } from 'typesafe-actions';
import { SummaryReducerType } from '../components/batchSummary/batchSummaryReducer';
import { DetailsReducerType } from '../components/batchDetails/batchDetailsReducer';
import { DownloadsReducerType } from '../components/downloads/downloadsReducer';
import * as AllActions from '../actions';

// Generic types
export interface StringTMap<T> { [key: string]: T; };
export interface NumberTMap<T> { [key: number]: T; };

export interface StringAnyMap extends StringTMap<any> {};
export interface NumberAnyMap extends NumberTMap<any> {};

export interface StringStringMap extends StringTMap<string> {};
export interface NumberStringMap extends NumberTMap<string> {};

export interface StringNumberMap extends StringTMap<number> {};
export interface NumberNumberMap extends NumberTMap<number> {};

export interface StringBooleanMap extends StringTMap<boolean> {};
export interface NumberBooleanMap extends NumberTMap<boolean> {};

// Global DTO

export interface IScenario {
    type: string;
    id: string;
    ukId: string;
    comments: string;
    validFrom: string;
    validTo: string;
    modifiedBy: string;
    addedBy: string;
    name: string;
    description: string;
    action: 'CREATE' | 'UPDATE';
    proposedFileVersion: number;
    activeFileVersion: number;
    category: string;
    tags: Array<string> | null;
    attachmentsUploaded: boolean;
    mtcrApprovalCommittee: null;
    pending: boolean;
}

export interface IBatch {
    type: string;
    id: string;
    ukId: string;
    comments: string;
    validFrom: string;
    validTo: string;
    modifiedBy: string;
    addedBy: string;
    scenarios: IScenario[];
    name: string;
    pctNode: string;
    pctNodeId: string;
    cobDate: any | null;
    action: string;
    addedScenarios: string;
    removedScenarios: string;
    activeScenarios: string;
    scheduleDto: any;
}

export interface navLinksType {
    title: string;
    to: string;
    text: string;
    id: string;
}

export interface IErrorTypeProps {
    message?: string;
    className?: string;
    important?: boolean;
    showError?: boolean;
}

// Reducer types
export interface AppState {
    BATCHES: SummaryReducerType;
    BATCH_DETAILS: DetailsReducerType;
    BATCH_AUDITS: any;
    BATCH_SCHEDULES: any;
    DOWNLOADS: DownloadsReducerType;
    INBOX: any;
    DIFF: any;
    SCENARIOS: any;
    SCENARIO_AUDITS: any;
    USER: any;
}

export interface IAuthReducer {
    isSigningIn: boolean;
    failedAuthentication: boolean;
    userDisplayName: string;
    entitlements: string;
}

export interface IDiffReducer {
    diff: any | {};
    isFetchingDiff: boolean;
    fetchDiffError: string;
}

// Action types
export type ErrorType = {
    error: string;
};

export type AllOtherRootActionsType = ActionType<typeof AllActions>;
