const path = require('path');
const webpack = require('webpack');
const HtmlWebpackPlugin = require('html-webpack-plugin');

const developConfig = {
    devtool: 'eval-source-map',
    mode: 'development',
    output: {
        path: path.join(__dirname, 'dist'),
        filename: '[name].bundle.js',
        chunkFilename: '[name].chunk.js',
    },
    plugins: [
        new HtmlWebpackPlugin({
            template: './src/index.html',
            inject: true,
            hash: true,
            filename: 'index.html',
        }),
        new webpack.HotModuleReplacementPlugin()
    ],
    resolve: {
        modules: [path.resolve('./src'), path.resolve('./node_modules')],
        extensions: ['.js', '.jsx', '.ts', '.tsx', '.json'],
    },
    module: {
        rules: [
            {
                test: /\.(js|jsx|ts|tsx)$/,
                include: [/src/],
                use: ['babel-loader', 'eslint-loader'],
            },
            {
                test: /\.(eot|ttf|woff|otf|woff2)$/,
                use: {
                    loader: 'file-loader?name=/fonts/[name].[ext]',
                    options: {
                        name: 'assets/fonts/[name].[ext]',
                    },
                },
            },
            {
                test: /\.(jpg|svg|png|gif|jpeg)$/,
                use: {
                    loader: 'file-loader?name=/images/[name].[ext]',
                    options: {
                        name: 'assets/images/[name].[ext]',
                    },
                },
            },
            {
                test: /\.scss$/,
                use: ['style-loader', 'css-loader', 'sass-loader'],
            },
            {
                test: /\.css$/,
                use: ['style-loader', 'css-loader'],
            }
        ],
    },
    devServer: {
        contentBase: path.resolve(__dirname, 'dist'),
        stats: { children: false },
        hot: true,
        compress: true,
        port: 8080,
        historyApiFallback: true,
        open: 'Chrome',
    },
};

module.exports = developConfig;
